<?php
$config['table_prefix']='';
$config['environment']='prod';//prod or test
$config['allowed_uncleared_days'] = 30;
$config['db_cache_on'] = true;
$config['page_cache_on'] = true;
$config['page_cache_duration'] = 30;//Minutes
