<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-05-15 03:53:45 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-05-15 05:05:40 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-05-15 05:07:30 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-05-15 05:18:06 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-05-15 05:58:48 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-05-15 06:01:40 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-05-15 06:07:15 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-05-15 06:08:53 --> Severity: Warning --> array_sum() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 868
ERROR - 2019-05-15 06:08:53 --> Query error: Column 'icpNo' cannot be null - Invalid query: INSERT INTO `voucher_header` (`icpNo`, `TDate`, `Fy`, `VNumber`, `Payee`, `Address`, `VType`, `ChqNo`, `TDescription`, `totals`, `unixStmp`) VALUES (NULL, '1970-01-01', '70', NULL, NULL, NULL, NULL, '-3', NULL, NULL, 1557900533)
ERROR - 2019-05-15 06:12:14 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-05-15 06:19:29 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-05-15 06:20:26 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-05-15 06:20:26 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-05-15 06:21:02 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-05-15 06:21:03 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-05-15 06:39:02 --> Query error: Column 'fy' cannot be null - Invalid query: INSERT INTO `planheader` (`icpNo`, `fy`) VALUES ('KE384', NULL)
ERROR - 2019-05-15 06:39:02 --> Query error: Column 'planHeaderID' cannot be null - Invalid query: INSERT INTO `plansschedule` (`planHeaderID`, `AccNo`, `plan_item_tag_id`, `details`, `qty`, `unitCost`, `often`, `totalCost`, `notes`, `month_1_amount`, `month_2_amount`, `month_3_amount`, `month_4_amount`, `month_5_amount`, `month_6_amount`, `month_7_amount`, `month_8_amount`, `month_9_amount`, `month_10_amount`, `month_11_amount`, `month_12_amount`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2019-05-15 06:39:32 --> Query error: Column 'fy' cannot be null - Invalid query: INSERT INTO `planheader` (`icpNo`, `fy`) VALUES ('KE384', NULL)
ERROR - 2019-05-15 06:39:32 --> Query error: Column 'planHeaderID' cannot be null - Invalid query: INSERT INTO `plansschedule` (`planHeaderID`, `AccNo`, `plan_item_tag_id`, `details`, `qty`, `unitCost`, `often`, `totalCost`, `notes`, `month_1_amount`, `month_2_amount`, `month_3_amount`, `month_4_amount`, `month_5_amount`, `month_6_amount`, `month_7_amount`, `month_8_amount`, `month_9_amount`, `month_10_amount`, `month_11_amount`, `month_12_amount`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2019-05-15 06:42:05 --> Query error: Column 'fy' cannot be null - Invalid query: INSERT INTO `planheader` (`icpNo`, `fy`) VALUES ('KE384', NULL)
ERROR - 2019-05-15 06:42:05 --> Query error: Column 'planHeaderID' cannot be null - Invalid query: INSERT INTO `plansschedule` (`planHeaderID`, `AccNo`, `plan_item_tag_id`, `details`, `qty`, `unitCost`, `often`, `totalCost`, `notes`, `month_1_amount`, `month_2_amount`, `month_3_amount`, `month_4_amount`, `month_5_amount`, `month_6_amount`, `month_7_amount`, `month_8_amount`, `month_9_amount`, `month_10_amount`, `month_11_amount`, `month_12_amount`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2019-05-15 06:42:12 --> Query error: Column 'fy' cannot be null - Invalid query: INSERT INTO `planheader` (`icpNo`, `fy`) VALUES ('KE384', NULL)
ERROR - 2019-05-15 06:42:12 --> Query error: Column 'planHeaderID' cannot be null - Invalid query: INSERT INTO `plansschedule` (`planHeaderID`, `AccNo`, `plan_item_tag_id`, `details`, `qty`, `unitCost`, `often`, `totalCost`, `notes`, `month_1_amount`, `month_2_amount`, `month_3_amount`, `month_4_amount`, `month_5_amount`, `month_6_amount`, `month_7_amount`, `month_8_amount`, `month_9_amount`, `month_10_amount`, `month_11_amount`, `month_12_amount`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2019-05-15 06:44:39 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 85
ERROR - 2019-05-15 06:44:39 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 568
ERROR - 2019-05-15 06:44:39 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 568
ERROR - 2019-05-15 06:44:39 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 573
ERROR - 2019-05-15 06:44:39 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 573
ERROR - 2019-05-15 06:44:39 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 30
ERROR - 2019-05-15 06:44:39 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 40
ERROR - 2019-05-15 06:44:39 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 50
ERROR - 2019-05-15 06:44:39 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 72
ERROR - 2019-05-15 06:44:39 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 78
ERROR - 2019-05-15 06:44:39 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 84
ERROR - 2019-05-15 06:44:39 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 91
ERROR - 2019-05-15 06:44:39 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 97
ERROR - 2019-05-15 06:44:39 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 103
ERROR - 2019-05-15 06:44:39 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 110
ERROR - 2019-05-15 06:44:39 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 117
ERROR - 2019-05-15 06:44:39 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 124
ERROR - 2019-05-15 06:44:39 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 132
ERROR - 2019-05-15 06:44:39 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 140
ERROR - 2019-05-15 06:44:39 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 148
ERROR - 2019-05-15 06:44:39 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 157
ERROR - 2019-05-15 06:44:39 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 159
ERROR - 2019-05-15 06:44:39 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 186
ERROR - 2019-05-15 06:44:39 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 186
ERROR - 2019-05-15 06:44:39 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 212
ERROR - 2019-05-15 06:44:39 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 214
ERROR - 2019-05-15 06:44:39 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 218
ERROR - 2019-05-15 06:44:39 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 219
ERROR - 2019-05-15 06:44:39 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 239
ERROR - 2019-05-15 06:44:39 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 245
ERROR - 2019-05-15 06:44:39 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 689
ERROR - 2019-05-15 06:47:57 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-05-15 06:55:11 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-05-15 07:12:24 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-05-15 07:13:28 --> Query error: Column 'fy' cannot be null - Invalid query: INSERT INTO `planheader` (`icpNo`, `fy`) VALUES ('KE384', NULL)
ERROR - 2019-05-15 07:13:28 --> Query error: Column 'planHeaderID' cannot be null - Invalid query: INSERT INTO `plansschedule` (`planHeaderID`, `AccNo`, `plan_item_tag_id`, `details`, `qty`, `unitCost`, `often`, `totalCost`, `notes`, `month_1_amount`, `month_2_amount`, `month_3_amount`, `month_4_amount`, `month_5_amount`, `month_6_amount`, `month_7_amount`, `month_8_amount`, `month_9_amount`, `month_10_amount`, `month_11_amount`, `month_12_amount`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2019-05-15 07:15:30 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-05-15 07:29:11 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 81
ERROR - 2019-05-15 07:29:11 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 82
ERROR - 2019-05-15 07:29:30 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-05-15 07:34:19 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-05-15 07:35:27 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-05-15 07:36:32 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 81
ERROR - 2019-05-15 07:36:32 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 82
ERROR - 2019-05-15 07:37:36 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-05-15 07:39:13 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-05-15 07:39:23 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-05-15 07:40:27 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-05-15 07:40:28 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-05-15 07:40:28 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-05-15 07:40:29 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-05-15 07:40:30 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-05-15 07:40:53 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-05-15 07:41:24 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-05-15 07:42:40 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-05-15 07:48:21 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-05-15 07:49:30 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-05-15 07:49:33 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-05-15 07:52:03 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-05-15 07:53:37 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-05-15 07:53:59 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-05-15 07:54:23 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-05-15 07:55:07 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-05-15 07:56:14 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-05-15 07:56:46 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-05-15 07:59:58 --> 404 Page Not Found: Facilitator/assets
ERROR - 2019-05-15 08:00:25 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-05-15 08:00:53 --> Severity: error --> Exception: Too few arguments to function Partner::create_budget_item(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 1043
ERROR - 2019-05-15 08:00:58 --> Severity: error --> Exception: Too few arguments to function Partner::create_budget_item(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 1043
ERROR - 2019-05-15 08:01:03 --> Severity: error --> Exception: Too few arguments to function Partner::create_budget_item(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 1043
ERROR - 2019-05-15 08:01:14 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-05-15 08:01:47 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-05-15 08:05:44 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-05-15 08:05:57 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-05-15 08:10:18 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 81
ERROR - 2019-05-15 08:10:18 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 82
ERROR - 2019-05-15 08:12:23 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-05-15 08:13:03 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-05-15 08:15:15 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-05-15 08:15:47 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-05-15 08:16:39 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-05-15 08:16:48 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-05-15 08:16:53 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-05-15 08:19:38 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-05-15 08:20:09 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-05-15 08:27:55 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-05-15 08:28:09 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-05-15 08:28:10 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-05-15 08:39:52 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-05-15 08:43:55 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-05-15 09:00:04 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-05-15 09:00:08 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-05-15 09:04:29 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-05-15 09:04:52 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-05-15 09:04:58 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-05-15 09:07:28 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-05-15 09:10:58 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-05-15 09:13:04 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-05-15 09:28:05 --> 404 Page Not Found: Facilitator/assets
ERROR - 2019-05-15 09:35:26 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-05-15 09:35:56 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-05-15 09:36:33 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-05-15 09:36:41 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-05-15 09:40:00 --> 404 Page Not Found: Facilitator/assets
ERROR - 2019-05-15 09:58:28 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-05-15 09:58:28 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-05-15 10:14:00 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-05-15 10:14:13 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-05-15 10:37:46 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-05-15 10:38:43 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-05-15 10:39:05 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-05-15 10:40:28 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-05-15 10:41:09 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-05-15 10:43:34 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-05-15 10:44:05 --> Query error: Column 'fy' cannot be null - Invalid query: INSERT INTO `planheader` (`icpNo`, `fy`) VALUES ('KE384', NULL)
ERROR - 2019-05-15 10:44:05 --> Query error: Column 'planHeaderID' cannot be null - Invalid query: INSERT INTO `plansschedule` (`planHeaderID`, `AccNo`, `plan_item_tag_id`, `details`, `qty`, `unitCost`, `often`, `totalCost`, `notes`, `month_1_amount`, `month_2_amount`, `month_3_amount`, `month_4_amount`, `month_5_amount`, `month_6_amount`, `month_7_amount`, `month_8_amount`, `month_9_amount`, `month_10_amount`, `month_11_amount`, `month_12_amount`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2019-05-15 10:46:08 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-05-15 10:50:12 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-05-15 10:53:47 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-05-15 10:54:26 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-05-15 10:55:58 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-05-15 11:02:12 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-05-15 11:04:27 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-05-15 11:08:22 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-05-15 11:08:34 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-05-15 11:10:15 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-05-15 11:14:48 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-05-15 11:15:26 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-05-15 11:17:37 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-05-15 11:18:30 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-05-15 11:19:17 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-05-15 11:21:24 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-05-15 11:21:56 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-05-15 11:24:46 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-05-15 11:30:08 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-05-15 11:30:08 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-05-15 11:43:18 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-05-15 11:46:34 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-05-15 11:53:24 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-05-15 11:57:32 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-05-15 12:01:00 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-05-15 12:05:41 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-05-15 12:08:48 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 81
ERROR - 2019-05-15 12:08:48 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 82
ERROR - 2019-05-15 12:10:40 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-05-15 12:12:07 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-05-15 12:15:23 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-05-15 12:16:22 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-05-15 12:16:31 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-05-15 12:21:10 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-05-15 12:26:10 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-05-15 12:26:52 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-05-15 12:32:04 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-05-15 12:35:13 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-05-15 12:36:15 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-05-15 12:39:52 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-05-15 12:46:09 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-05-15 12:50:14 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-05-15 12:50:51 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-05-15 12:51:31 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-05-15 12:52:15 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-05-15 12:52:51 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-05-15 12:54:29 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 81
ERROR - 2019-05-15 12:54:29 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 82
ERROR - 2019-05-15 12:56:47 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-05-15 12:57:41 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-05-15 12:59:55 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-05-15 13:00:37 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-05-15 13:00:37 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-05-15 13:00:38 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-05-15 13:00:39 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-05-15 13:00:41 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-05-15 13:03:37 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-05-15 13:07:46 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 81
ERROR - 2019-05-15 13:07:46 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 82
ERROR - 2019-05-15 13:10:06 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-05-15 13:13:02 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-05-15 13:16:14 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-05-15 13:20:36 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-05-15 13:21:10 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-05-15 13:26:50 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-05-15 13:27:06 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-05-15 13:27:54 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-05-15 13:28:05 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-05-15 13:31:53 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-05-15 13:35:20 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-05-15 13:39:11 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-05-15 13:46:01 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-05-15 13:49:15 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-05-15 14:02:59 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-05-15 14:06:08 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-05-15 14:06:31 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-05-15 14:08:39 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-05-15 14:19:59 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-05-15 14:22:12 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-05-15 14:23:59 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-05-15 14:24:01 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-05-15 14:30:16 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-05-15 14:33:05 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-05-15 14:55:52 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-05-15 15:16:42 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-05-15 15:16:44 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-05-15 15:16:44 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-05-15 15:16:57 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-05-15 15:17:02 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-05-15 17:20:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:20:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-05-15 17:32:38 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
