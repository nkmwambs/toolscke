<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-06-05 03:10:45 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-05 03:10:45 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-05 03:10:46 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-05 03:10:47 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-05 05:29:34 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-05 05:30:08 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-05 05:46:46 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-05 05:47:15 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-05 06:02:09 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-05 07:05:44 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-05 07:06:19 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-05 07:09:26 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-05 07:38:32 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-06-05 07:46:31 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-05 08:02:19 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-05 08:03:40 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-05 08:07:01 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-05 08:07:01 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-05 08:07:01 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-05 08:07:01 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-05 08:07:01 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-05 08:07:01 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-05 08:07:02 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-05 08:07:07 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-05 08:10:27 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-05 08:19:59 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-05 08:21:22 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-05 08:23:03 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-05 08:25:16 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-05 08:34:44 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-05 08:50:10 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-05 08:51:15 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-05 08:51:54 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-05 08:53:10 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-05 09:08:30 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-05 09:10:58 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-05 09:15:05 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-05 09:18:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:18:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:19:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:19:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:19:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:19:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:19:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:19:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:19:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:19:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:19:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:19:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:19:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:19:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:19:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:19:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:19:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:19:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:19:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:19:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:19:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:19:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:19:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:19:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:19:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:19:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:19:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:19:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:19:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:19:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:19:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:19:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:19:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:19:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:19:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:19:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:19:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:19:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:19:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:19:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:19:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:19:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:19:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:19:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:19:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:19:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:19:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:19:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:19:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:19:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:19:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:19:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:19:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:19:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:19:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:19:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 09:19:48 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-05 09:21:50 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-05 09:23:16 --> Query error: Column 'fy' cannot be null - Invalid query: INSERT INTO `planheader` (`icpNo`, `fy`) VALUES ('KE643', NULL)
ERROR - 2019-06-05 09:23:16 --> Query error: Column 'planHeaderID' cannot be null - Invalid query: INSERT INTO `plansschedule` (`planHeaderID`, `AccNo`, `plan_item_tag_id`, `details`, `qty`, `unitCost`, `often`, `totalCost`, `notes`, `month_1_amount`, `month_2_amount`, `month_3_amount`, `month_4_amount`, `month_5_amount`, `month_6_amount`, `month_7_amount`, `month_8_amount`, `month_9_amount`, `month_10_amount`, `month_11_amount`, `month_12_amount`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2019-06-05 09:23:57 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-05 09:25:15 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-05 09:26:28 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-05 09:27:17 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-05 09:29:07 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-05 09:30:59 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-05 09:35:41 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-05 09:36:16 --> Query error: Column 'fy' cannot be null - Invalid query: INSERT INTO `planheader` (`icpNo`, `fy`) VALUES ('KE510', NULL)
ERROR - 2019-06-05 09:36:16 --> Query error: Column 'planHeaderID' cannot be null - Invalid query: INSERT INTO `plansschedule` (`planHeaderID`, `AccNo`, `plan_item_tag_id`, `details`, `qty`, `unitCost`, `often`, `totalCost`, `notes`, `month_1_amount`, `month_2_amount`, `month_3_amount`, `month_4_amount`, `month_5_amount`, `month_6_amount`, `month_7_amount`, `month_8_amount`, `month_9_amount`, `month_10_amount`, `month_11_amount`, `month_12_amount`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2019-06-05 09:36:29 --> Query error: Column 'fy' cannot be null - Invalid query: INSERT INTO `planheader` (`icpNo`, `fy`) VALUES ('KE510', NULL)
ERROR - 2019-06-05 09:36:29 --> Query error: Column 'planHeaderID' cannot be null - Invalid query: INSERT INTO `plansschedule` (`planHeaderID`, `AccNo`, `plan_item_tag_id`, `details`, `qty`, `unitCost`, `often`, `totalCost`, `notes`, `month_1_amount`, `month_2_amount`, `month_3_amount`, `month_4_amount`, `month_5_amount`, `month_6_amount`, `month_7_amount`, `month_8_amount`, `month_9_amount`, `month_10_amount`, `month_11_amount`, `month_12_amount`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2019-06-05 09:38:59 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-05 09:39:03 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-05 09:39:04 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-05 09:39:04 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-05 09:40:07 --> Query error: Column 'fy' cannot be null - Invalid query: INSERT INTO `planheader` (`icpNo`, `fy`) VALUES ('KE643', NULL)
ERROR - 2019-06-05 09:40:07 --> Query error: Column 'planHeaderID' cannot be null - Invalid query: INSERT INTO `plansschedule` (`planHeaderID`, `AccNo`, `plan_item_tag_id`, `details`, `qty`, `unitCost`, `often`, `totalCost`, `notes`, `month_1_amount`, `month_2_amount`, `month_3_amount`, `month_4_amount`, `month_5_amount`, `month_6_amount`, `month_7_amount`, `month_8_amount`, `month_9_amount`, `month_10_amount`, `month_11_amount`, `month_12_amount`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2019-06-05 09:40:33 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-05 09:44:24 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-05 09:45:46 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-05 09:46:29 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-05 09:46:45 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-06-05 09:47:56 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-05 09:48:41 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-06-05 09:49:03 --> Query error: Column 'fy' cannot be null - Invalid query: INSERT INTO `planheader` (`icpNo`, `fy`) VALUES ('KE643', NULL)
ERROR - 2019-06-05 09:49:03 --> Query error: Column 'planHeaderID' cannot be null - Invalid query: INSERT INTO `plansschedule` (`planHeaderID`, `AccNo`, `plan_item_tag_id`, `details`, `qty`, `unitCost`, `often`, `totalCost`, `notes`, `month_1_amount`, `month_2_amount`, `month_3_amount`, `month_4_amount`, `month_5_amount`, `month_6_amount`, `month_7_amount`, `month_8_amount`, `month_9_amount`, `month_10_amount`, `month_11_amount`, `month_12_amount`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2019-06-05 09:49:07 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-05 09:54:37 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-05 09:59:31 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-05 10:01:01 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-05 10:07:02 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-05 10:08:32 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-05 10:10:17 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-05 10:11:25 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-05 10:12:51 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-05 10:12:59 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-05 10:13:54 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-05 10:17:13 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-05 10:35:48 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-05 10:40:46 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-05 10:43:13 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-05 10:48:06 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 81
ERROR - 2019-06-05 10:48:06 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 82
ERROR - 2019-06-05 10:58:59 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 81
ERROR - 2019-06-05 10:58:59 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 82
ERROR - 2019-06-05 11:00:22 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 81
ERROR - 2019-06-05 11:00:22 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 82
ERROR - 2019-06-05 11:32:50 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 81
ERROR - 2019-06-05 11:32:50 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 82
ERROR - 2019-06-05 11:33:11 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 81
ERROR - 2019-06-05 11:33:11 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 82
ERROR - 2019-06-05 11:40:12 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-05 11:40:13 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-05 11:40:14 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-05 11:40:16 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-05 11:40:17 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-05 11:40:19 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-05 11:46:31 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-05 11:47:59 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-06-05 13:17:01 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-05 13:17:03 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-05 13:22:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 13:22:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 13:22:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 13:22:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 13:22:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 13:22:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 13:22:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 13:22:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 13:22:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 13:22:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 13:22:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 13:22:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 13:22:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 13:22:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 13:22:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 13:22:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 13:22:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 13:22:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 13:22:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 13:22:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 13:22:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 13:22:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 13:22:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 13:22:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 13:22:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 13:22:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 13:22:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 13:22:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 13:22:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 13:22:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 13:22:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 13:22:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 13:22:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 13:22:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 13:22:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 13:22:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 13:22:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 13:22:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 13:22:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 13:22:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 13:22:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 13:22:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 13:22:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 13:22:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 13:22:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 13:22:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 13:22:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 13:22:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 13:22:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 13:22:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 13:22:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 13:22:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 13:22:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 13:22:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 14:32:48 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-05 14:32:49 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-05 14:32:49 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-05 14:32:58 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-05 14:33:00 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-05 14:33:03 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-05 14:33:10 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-05 14:33:12 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-05 14:33:52 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-05 14:34:13 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-05 14:35:29 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-05 14:35:38 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-05 14:35:40 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-05 14:40:07 --> 404 Page Not Found: Civa/assets
ERROR - 2019-06-05 14:40:11 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-05 14:40:12 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-05 14:40:12 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-05 15:05:40 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-05 15:05:42 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-05 17:16:07 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-06-05 17:25:13 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-05 17:31:40 --> 404 Page Not Found: Civa/assets
ERROR - 2019-06-05 17:31:59 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-05 17:37:28 --> 404 Page Not Found: Civa/assets
ERROR - 2019-06-05 17:43:22 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-06-05 17:46:01 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-06-05 18:13:10 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-05 18:13:12 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-05 18:13:14 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-05 18:13:14 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-05 18:13:14 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-05 18:45:58 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-05 19:23:03 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-05 19:36:22 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-05 20:02:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 20:02:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 20:02:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 20:02:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 20:02:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 20:02:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 20:02:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 20:02:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 20:02:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 20:02:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 20:02:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 20:02:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 20:02:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 20:02:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 20:02:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 20:02:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 20:02:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 20:02:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 20:02:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 20:02:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 20:02:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 20:02:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 20:02:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 20:02:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 20:02:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 20:02:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 20:02:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 20:02:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 20:02:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 20:02:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 20:02:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 20:02:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 20:02:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 20:02:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 20:02:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 20:02:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 20:02:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 20:02:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 20:02:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 20:02:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 20:02:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 20:02:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 20:02:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 20:02:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 20:02:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 20:02:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 20:02:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 20:02:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 20:02:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 20:02:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 20:02:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 20:02:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 20:02:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 20:02:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 20:02:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 20:02:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-05 20:16:19 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-05 20:16:24 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-05 20:22:47 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-05 20:24:55 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-05 20:26:18 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-05 22:11:08 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
