<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-06-16 09:19:03 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-06-16 09:19:16 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-06-16 09:19:30 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-06-16 13:50:01 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-16 14:12:38 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-16 14:13:06 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-16 14:50:52 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-16 18:02:31 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-16 18:40:50 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
