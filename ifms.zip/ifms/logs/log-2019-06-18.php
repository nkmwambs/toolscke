<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-06-18 05:38:04 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 05:43:47 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 06:24:06 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 06:29:55 --> Query error: Column 'fy' cannot be null - Invalid query: INSERT INTO `planheader` (`icpNo`, `fy`) VALUES ('KE901', NULL)
ERROR - 2019-06-18 06:29:55 --> Query error: Column 'planHeaderID' cannot be null - Invalid query: INSERT INTO `plansschedule` (`planHeaderID`, `AccNo`, `plan_item_tag_id`, `details`, `qty`, `unitCost`, `often`, `totalCost`, `notes`, `month_1_amount`, `month_2_amount`, `month_3_amount`, `month_4_amount`, `month_5_amount`, `month_6_amount`, `month_7_amount`, `month_8_amount`, `month_9_amount`, `month_10_amount`, `month_11_amount`, `month_12_amount`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2019-06-18 06:32:33 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 06:34:26 --> Query error: Column 'fy' cannot be null - Invalid query: INSERT INTO `planheader` (`icpNo`, `fy`) VALUES ('KE901', NULL)
ERROR - 2019-06-18 06:34:26 --> Query error: Column 'planHeaderID' cannot be null - Invalid query: INSERT INTO `plansschedule` (`planHeaderID`, `AccNo`, `plan_item_tag_id`, `details`, `qty`, `unitCost`, `often`, `totalCost`, `notes`, `month_1_amount`, `month_2_amount`, `month_3_amount`, `month_4_amount`, `month_5_amount`, `month_6_amount`, `month_7_amount`, `month_8_amount`, `month_9_amount`, `month_10_amount`, `month_11_amount`, `month_12_amount`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2019-06-18 06:34:29 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 06:34:49 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-06-18 06:35:36 --> Query error: Column 'fy' cannot be null - Invalid query: INSERT INTO `planheader` (`icpNo`, `fy`) VALUES ('KE901', NULL)
ERROR - 2019-06-18 06:35:36 --> Query error: Column 'planHeaderID' cannot be null - Invalid query: INSERT INTO `plansschedule` (`planHeaderID`, `AccNo`, `plan_item_tag_id`, `details`, `qty`, `unitCost`, `often`, `totalCost`, `notes`, `month_1_amount`, `month_2_amount`, `month_3_amount`, `month_4_amount`, `month_5_amount`, `month_6_amount`, `month_7_amount`, `month_8_amount`, `month_9_amount`, `month_10_amount`, `month_11_amount`, `month_12_amount`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2019-06-18 06:36:47 --> Query error: Column 'fy' cannot be null - Invalid query: INSERT INTO `planheader` (`icpNo`, `fy`) VALUES ('KE901', NULL)
ERROR - 2019-06-18 06:36:47 --> Query error: Column 'planHeaderID' cannot be null - Invalid query: INSERT INTO `plansschedule` (`planHeaderID`, `AccNo`, `plan_item_tag_id`, `details`, `qty`, `unitCost`, `often`, `totalCost`, `notes`, `month_1_amount`, `month_2_amount`, `month_3_amount`, `month_4_amount`, `month_5_amount`, `month_6_amount`, `month_7_amount`, `month_8_amount`, `month_9_amount`, `month_10_amount`, `month_11_amount`, `month_12_amount`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2019-06-18 06:37:34 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 06:44:12 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 06:46:38 --> Query error: Column 'fy' cannot be null - Invalid query: INSERT INTO `planheader` (`icpNo`, `fy`) VALUES ('KE901', NULL)
ERROR - 2019-06-18 06:46:38 --> Query error: Column 'planHeaderID' cannot be null - Invalid query: INSERT INTO `plansschedule` (`planHeaderID`, `AccNo`, `plan_item_tag_id`, `details`, `qty`, `unitCost`, `often`, `totalCost`, `notes`, `month_1_amount`, `month_2_amount`, `month_3_amount`, `month_4_amount`, `month_5_amount`, `month_6_amount`, `month_7_amount`, `month_8_amount`, `month_9_amount`, `month_10_amount`, `month_11_amount`, `month_12_amount`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2019-06-18 06:47:07 --> Query error: Column 'fy' cannot be null - Invalid query: INSERT INTO `planheader` (`icpNo`, `fy`) VALUES ('KE901', NULL)
ERROR - 2019-06-18 06:47:07 --> Query error: Column 'planHeaderID' cannot be null - Invalid query: INSERT INTO `plansschedule` (`planHeaderID`, `AccNo`, `plan_item_tag_id`, `details`, `qty`, `unitCost`, `often`, `totalCost`, `notes`, `month_1_amount`, `month_2_amount`, `month_3_amount`, `month_4_amount`, `month_5_amount`, `month_6_amount`, `month_7_amount`, `month_8_amount`, `month_9_amount`, `month_10_amount`, `month_11_amount`, `month_12_amount`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2019-06-18 06:48:44 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 06:53:34 --> Query error: Column 'fy' cannot be null - Invalid query: INSERT INTO `planheader` (`icpNo`, `fy`) VALUES ('KE901', NULL)
ERROR - 2019-06-18 06:53:34 --> Query error: Column 'planHeaderID' cannot be null - Invalid query: INSERT INTO `plansschedule` (`planHeaderID`, `AccNo`, `plan_item_tag_id`, `details`, `qty`, `unitCost`, `often`, `totalCost`, `notes`, `month_1_amount`, `month_2_amount`, `month_3_amount`, `month_4_amount`, `month_5_amount`, `month_6_amount`, `month_7_amount`, `month_8_amount`, `month_9_amount`, `month_10_amount`, `month_11_amount`, `month_12_amount`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2019-06-18 06:54:20 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 06:55:13 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 06:56:03 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 07:00:54 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-18 07:24:31 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 07:26:40 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 07:31:34 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 07:34:35 --> Query error: Column 'fy' cannot be null - Invalid query: INSERT INTO `planheader` (`icpNo`, `fy`) VALUES ('KE901', NULL)
ERROR - 2019-06-18 07:34:35 --> Query error: Column 'planHeaderID' cannot be null - Invalid query: INSERT INTO `plansschedule` (`planHeaderID`, `AccNo`, `plan_item_tag_id`, `details`, `qty`, `unitCost`, `often`, `totalCost`, `notes`, `month_1_amount`, `month_2_amount`, `month_3_amount`, `month_4_amount`, `month_5_amount`, `month_6_amount`, `month_7_amount`, `month_8_amount`, `month_9_amount`, `month_10_amount`, `month_11_amount`, `month_12_amount`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2019-06-18 07:35:56 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-18 07:36:05 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-18 07:36:06 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-18 07:36:07 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-18 07:36:15 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-18 07:36:21 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-18 07:36:25 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-18 07:40:40 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 07:42:17 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 07:45:50 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-06-18 07:50:19 --> Query error: Column 'fy' cannot be null - Invalid query: INSERT INTO `planheader` (`icpNo`, `fy`) VALUES ('KE901', NULL)
ERROR - 2019-06-18 07:50:19 --> Query error: Column 'planHeaderID' cannot be null - Invalid query: INSERT INTO `plansschedule` (`planHeaderID`, `AccNo`, `plan_item_tag_id`, `details`, `qty`, `unitCost`, `often`, `totalCost`, `notes`, `month_1_amount`, `month_2_amount`, `month_3_amount`, `month_4_amount`, `month_5_amount`, `month_6_amount`, `month_7_amount`, `month_8_amount`, `month_9_amount`, `month_10_amount`, `month_11_amount`, `month_12_amount`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2019-06-18 07:56:30 --> Query error: Column 'fy' cannot be null - Invalid query: INSERT INTO `planheader` (`icpNo`, `fy`) VALUES ('KE901', NULL)
ERROR - 2019-06-18 07:56:30 --> Query error: Column 'planHeaderID' cannot be null - Invalid query: INSERT INTO `plansschedule` (`planHeaderID`, `AccNo`, `plan_item_tag_id`, `details`, `qty`, `unitCost`, `often`, `totalCost`, `notes`, `month_1_amount`, `month_2_amount`, `month_3_amount`, `month_4_amount`, `month_5_amount`, `month_6_amount`, `month_7_amount`, `month_8_amount`, `month_9_amount`, `month_10_amount`, `month_11_amount`, `month_12_amount`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2019-06-18 07:57:18 --> Query error: Column 'fy' cannot be null - Invalid query: INSERT INTO `planheader` (`icpNo`, `fy`) VALUES ('KE901', NULL)
ERROR - 2019-06-18 07:57:18 --> Query error: Column 'planHeaderID' cannot be null - Invalid query: INSERT INTO `plansschedule` (`planHeaderID`, `AccNo`, `plan_item_tag_id`, `details`, `qty`, `unitCost`, `often`, `totalCost`, `notes`, `month_1_amount`, `month_2_amount`, `month_3_amount`, `month_4_amount`, `month_5_amount`, `month_6_amount`, `month_7_amount`, `month_8_amount`, `month_9_amount`, `month_10_amount`, `month_11_amount`, `month_12_amount`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2019-06-18 08:07:18 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-06-18 08:12:02 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-18 08:23:54 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-18 08:27:58 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 08:33:18 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-18 08:33:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:33:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:33:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:33:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:33:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:33:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:33:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:33:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:33:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:33:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:33:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:33:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:33:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:33:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:33:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:33:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:33:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:33:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:33:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:33:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:33:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:33:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:33:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:33:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:33:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:33:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:33:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:33:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:33:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:33:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:33:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:33:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:33:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:33:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:33:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:33:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:33:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:33:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:33:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:33:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:33:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:33:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:33:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:33:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:33:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:33:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:33:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:33:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:33:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:33:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:33:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:33:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:33:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:33:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:33:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:33:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:33:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:33:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:33:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:34:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:34:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:34:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:34:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:34:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:34:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:34:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:34:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:34:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:34:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:34:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:34:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:34:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:34:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:34:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:34:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:34:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:34:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:34:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:34:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:34:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:34:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:34:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:34:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:34:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:34:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:34:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:34:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:34:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:34:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:34:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:34:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:34:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:34:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:34:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:34:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:34:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:34:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:34:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:34:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:34:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:34:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:34:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:34:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:34:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:34:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:34:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:34:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:34:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:34:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:34:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:34:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:34:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:34:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:34:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:34:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:34:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:34:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:34:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:35:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:36:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 08:38:38 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 08:38:50 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 08:39:13 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 08:39:21 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-18 08:39:23 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 08:41:27 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 08:41:36 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 08:43:10 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 08:43:15 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-18 08:43:21 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-18 08:43:37 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 08:45:08 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 08:46:19 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-06-18 08:46:29 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-18 08:46:44 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 08:48:44 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 08:49:32 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 08:50:09 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 08:51:56 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 08:56:50 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-18 08:58:07 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 08:59:16 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 08:59:53 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 09:00:33 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-06-18 09:02:10 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 09:02:37 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-18 09:04:02 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 09:07:50 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 09:09:32 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 09:12:01 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 09:13:20 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 09:13:56 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-06-18 09:16:36 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 09:25:58 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 09:29:17 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-06-18 09:31:34 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 09:35:27 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 09:36:57 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 09:37:11 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-18 09:37:11 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 09:43:10 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 09:44:30 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 09:46:23 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 09:50:12 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 09:50:55 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 09:51:23 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 09:57:50 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 10:00:10 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 10:01:43 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 10:09:27 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 10:13:53 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 10:15:30 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 10:16:04 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-18 10:16:25 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-18 10:18:30 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 10:19:46 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 10:23:10 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-18 10:29:34 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 10:37:27 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 10:39:19 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 10:40:51 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 10:43:13 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 10:44:36 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 10:45:34 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-06-18 10:45:56 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 10:46:01 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-06-18 10:46:55 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-06-18 10:46:57 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-06-18 10:47:31 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-06-18 10:49:14 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-18 10:49:33 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-18 10:50:32 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 10:51:56 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 10:54:52 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 10:56:13 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 11:02:29 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 11:04:20 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 11:05:23 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-18 11:05:24 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-18 11:08:15 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-18 11:31:50 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 11:39:27 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 11:41:55 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 11:45:07 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 11:45:50 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 11:46:34 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 11:46:37 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 11:47:59 --> Query error: Column 'fy' cannot be null - Invalid query: INSERT INTO `planheader` (`icpNo`, `fy`) VALUES ('KE758', NULL)
ERROR - 2019-06-18 11:47:59 --> Query error: Column 'planHeaderID' cannot be null - Invalid query: INSERT INTO `plansschedule` (`planHeaderID`, `AccNo`, `plan_item_tag_id`, `details`, `qty`, `unitCost`, `often`, `totalCost`, `notes`, `month_1_amount`, `month_2_amount`, `month_3_amount`, `month_4_amount`, `month_5_amount`, `month_6_amount`, `month_7_amount`, `month_8_amount`, `month_9_amount`, `month_10_amount`, `month_11_amount`, `month_12_amount`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2019-06-18 11:49:27 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 11:49:30 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 81
ERROR - 2019-06-18 11:49:30 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 82
ERROR - 2019-06-18 11:51:14 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 11:51:20 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 81
ERROR - 2019-06-18 11:51:20 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 82
ERROR - 2019-06-18 11:54:29 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 11:59:03 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 11:59:03 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 11:59:03 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 11:59:03 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 11:59:03 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 11:59:03 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 11:59:03 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 11:59:03 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 11:59:03 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 11:59:03 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 11:59:03 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 11:59:03 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 11:59:03 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 11:59:03 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 11:59:03 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 11:59:03 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 11:59:03 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 11:59:03 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 11:59:03 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 11:59:03 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 11:59:03 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 11:59:03 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 11:59:03 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 11:59:03 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 11:59:03 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 11:59:03 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 11:59:03 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 11:59:03 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 11:59:03 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 11:59:03 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 11:59:03 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 11:59:03 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 11:59:03 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 11:59:03 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 11:59:03 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 11:59:03 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 11:59:03 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 11:59:03 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 11:59:03 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 11:59:03 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 11:59:03 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 11:59:03 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 11:59:03 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 11:59:03 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 11:59:03 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 11:59:03 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 11:59:03 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 11:59:03 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 11:59:03 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 11:59:03 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 11:59:03 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 11:59:03 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 11:59:03 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 11:59:03 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 11:59:03 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 11:59:03 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 11:59:03 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 11:59:03 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 11:59:03 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:00:41 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 12:01:06 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 12:02:09 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 12:03:42 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 12:07:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:07:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:17:17 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 12:17:58 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 12:25:22 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 12:25:46 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 12:30:17 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 12:31:54 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-18 12:31:54 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-18 12:33:32 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 12:34:20 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 12:41:01 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 12:42:19 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 12:43:41 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 12:45:42 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 12:46:53 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 12:47:19 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 12:49:07 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 12:49:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:49:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 12:51:35 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 12:52:07 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 12:58:55 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 12:59:28 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 13:00:29 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 13:00:48 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-18 13:11:55 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-18 13:12:48 --> Query error: Column 'userid' cannot be null - Invalid query: INSERT INTO `detail` (`recid`, `userid`, `rson`, `app_name`) VALUES ('1539793', NULL, 'This is too high budget, where is the breakdown and raionale?', NULL)
ERROR - 2019-06-18 13:13:43 --> Query error: Column 'userid' cannot be null - Invalid query: INSERT INTO `detail` (`recid`, `userid`, `rson`, `app_name`) VALUES ('1539795', NULL, 'Too high budget, where is the justification and breakdown?', NULL)
ERROR - 2019-06-18 13:14:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:14:47 --> Query error: Column 'userid' cannot be null - Invalid query: INSERT INTO `detail` (`recid`, `userid`, `rson`, `app_name`) VALUES ('1541131', NULL, 'Move this item to account 70', NULL)
ERROR - 2019-06-18 13:17:09 --> Query error: Column 'userid' cannot be null - Invalid query: INSERT INTO `detail` (`recid`, `userid`, `rson`, `app_name`) VALUES ('1539799', NULL, 'You budgted for 106K and here you are changing the figures why?', NULL)
ERROR - 2019-06-18 13:17:53 --> Query error: Column 'userid' cannot be null - Invalid query: INSERT INTO `detail` (`recid`, `userid`, `rson`, `app_name`) VALUES ('1539799', NULL, 'You had put 106K in the word document budget and here you are changing the figures. why?', NULL)
ERROR - 2019-06-18 13:26:07 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 13:26:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:26:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:27:41 --> Query error: Column 'userid' cannot be null - Invalid query: INSERT INTO `detail` (`recid`, `userid`, `rson`, `app_name`) VALUES ('1541377', NULL, 'This is not wages, please move this item to account 520', NULL)
ERROR - 2019-06-18 13:32:28 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-18 13:41:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:41:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:41:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:41:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:41:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:41:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:41:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:41:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:41:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:41:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:41:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:41:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:41:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:41:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:41:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:41:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:41:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:41:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:41:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:41:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:41:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:41:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:41:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:41:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:41:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:41:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:41:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:41:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:41:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:41:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:41:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:41:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:41:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:41:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:41:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:41:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:41:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:41:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:41:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:41:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:41:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:41:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:41:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:41:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:41:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:41:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:41:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:41:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:41:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:41:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:41:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:41:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:41:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:41:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:41:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:41:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:41:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:41:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:41:37 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:43:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:43:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:43:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:43:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:43:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:43:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:43:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:43:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:43:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:43:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:43:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:43:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:43:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:43:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:43:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:43:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:43:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:43:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:43:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:43:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:43:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:43:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:43:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:43:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:43:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:43:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:43:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:43:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:43:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:43:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:43:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:43:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:43:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:43:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:43:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:43:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:43:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:43:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:43:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:43:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:43:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:43:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:43:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:43:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:43:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:43:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:43:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:43:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:43:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:43:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:43:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:43:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:43:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:43:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:43:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:43:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:43:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:43:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 13:43:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-18 14:39:48 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 15:09:21 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-18 15:15:46 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-18 15:15:50 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-18 15:16:15 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-06-18 15:20:29 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-18 16:21:25 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 85
ERROR - 2019-06-18 16:21:25 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 568
ERROR - 2019-06-18 16:21:25 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 568
ERROR - 2019-06-18 16:21:25 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 573
ERROR - 2019-06-18 16:21:25 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 573
ERROR - 2019-06-18 16:21:25 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 30
ERROR - 2019-06-18 16:21:25 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 40
ERROR - 2019-06-18 16:21:26 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 50
ERROR - 2019-06-18 16:21:26 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 72
ERROR - 2019-06-18 16:21:26 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 78
ERROR - 2019-06-18 16:21:26 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 84
ERROR - 2019-06-18 16:21:26 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 91
ERROR - 2019-06-18 16:21:26 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 97
ERROR - 2019-06-18 16:21:26 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 103
ERROR - 2019-06-18 16:21:26 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 110
ERROR - 2019-06-18 16:21:26 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 117
ERROR - 2019-06-18 16:21:26 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 124
ERROR - 2019-06-18 16:21:26 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 132
ERROR - 2019-06-18 16:21:26 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 140
ERROR - 2019-06-18 16:21:26 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 148
ERROR - 2019-06-18 16:21:26 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 157
ERROR - 2019-06-18 16:21:26 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 159
ERROR - 2019-06-18 16:21:26 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 186
ERROR - 2019-06-18 16:21:26 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 186
ERROR - 2019-06-18 16:21:26 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 212
ERROR - 2019-06-18 16:21:26 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 214
ERROR - 2019-06-18 16:21:26 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 218
ERROR - 2019-06-18 16:21:26 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 219
ERROR - 2019-06-18 16:21:26 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 239
ERROR - 2019-06-18 16:21:26 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 245
ERROR - 2019-06-18 16:21:26 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 689
ERROR - 2019-06-18 16:21:33 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 81
ERROR - 2019-06-18 16:21:33 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 82
ERROR - 2019-06-18 16:54:40 --> 404 Page Not Found: Civa/assets
ERROR - 2019-06-18 16:54:45 --> 404 Page Not Found: Civa/assets
ERROR - 2019-06-18 18:09:59 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/facilitator/modal_fund_ratios.php 32
ERROR - 2019-06-18 19:02:46 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 19:10:39 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 19:26:38 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-18 19:26:39 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-18 19:26:40 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-18 19:27:00 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-18 19:38:49 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 19:43:38 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 19:46:03 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 19:47:41 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-18 19:48:14 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
