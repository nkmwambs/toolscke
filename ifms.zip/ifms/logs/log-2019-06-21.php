<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-06-21 05:29:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:29:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:29:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:29:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:29:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:29:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:29:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:29:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:29:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:29:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:29:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:29:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:29:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:29:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:29:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:29:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:29:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:29:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:29:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:29:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:29:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:29:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:29:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:29:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:29:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:29:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:29:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:29:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:29:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:29:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:29:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:29:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:29:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:29:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:29:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:29:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:29:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:29:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:29:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:29:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:29:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:29:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:29:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:29:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:29:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:29:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:29:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:29:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:29:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:29:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:29:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:29:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:29:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:29:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:29:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:29:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:29:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:29:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:29:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:38:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:38:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:38:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:38:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:38:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:38:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:38:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:38:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:38:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:38:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:38:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:38:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:38:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:38:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:38:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:38:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:38:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:38:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:38:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:38:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:38:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:38:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:38:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:38:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:38:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:38:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:38:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:38:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:38:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:38:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:38:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:38:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:38:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:38:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:38:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:38:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:38:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:38:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:38:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:38:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:38:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:38:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:38:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:38:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:38:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:38:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:38:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:38:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:38:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:38:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:38:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:38:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:38:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:38:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:38:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:38:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:38:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:38:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:38:56 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:39:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:39:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:39:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:39:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:39:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:39:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:39:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:39:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:39:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:39:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:39:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:39:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:39:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:39:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:39:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:39:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:39:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:39:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:39:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:39:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:39:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:39:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:39:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:39:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:39:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:39:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:39:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:39:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:39:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:39:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:39:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:39:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:39:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:39:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:39:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:39:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:39:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:39:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:39:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:39:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:39:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:39:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:39:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:39:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:39:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:39:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:39:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:39:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:39:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:39:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:39:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:39:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:39:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:39:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:39:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:39:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:39:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:39:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:39:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-21 05:59:03 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-06-21 06:34:16 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-06-21 07:33:12 --> 404 Page Not Found: Civa/assets
ERROR - 2019-06-21 07:33:37 --> 404 Page Not Found: Civa/assets
ERROR - 2019-06-21 07:57:34 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-21 07:58:19 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-21 07:59:18 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-21 08:00:03 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-21 08:01:10 --> 404 Page Not Found: Civa/assets
ERROR - 2019-06-21 08:03:40 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-21 08:04:52 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-21 08:08:01 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-21 08:09:21 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-21 08:11:04 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-21 08:12:43 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-21 08:13:35 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-21 08:14:34 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-21 08:16:16 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-21 08:18:08 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-21 08:18:58 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-21 08:34:01 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-21 08:39:33 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-21 08:45:01 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-21 08:53:11 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-21 09:10:16 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-21 09:10:17 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-21 09:10:18 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-21 10:07:34 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-21 10:09:17 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-21 10:09:17 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-21 10:09:19 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-21 10:09:19 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-21 10:09:21 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-21 10:19:39 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-21 10:20:26 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-21 10:21:43 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-21 10:36:50 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-21 10:45:25 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-21 10:48:43 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/health/dashboard.php 12
ERROR - 2019-06-21 10:49:33 --> Severity: Error --> Allowed memory size of 402653184 bytes exhausted (tried to allocate 16384 bytes) /home/compatl8/public_html/tools/system/database/drivers/pdo/pdo_driver.php 184
ERROR - 2019-06-21 10:49:52 --> Query error: Cannot execute queries while other unbuffered queries are active.  Consider using PDOStatement::fetchAll().  Alternatively, if your code is only ever going to run against mysql, you may enable query buffering by setting the PDO::MYSQL_ATTR_USE_BUFFERED_QUERY attribute. - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1561114192
WHERE `id` = 'd268526ef3c2ec51bbbb9adaab551e2600efeedf'
ERROR - 2019-06-21 10:49:52 --> Severity: Warning --> Unknown: Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-21 10:49:52 --> Query error: Cannot execute queries while other unbuffered queries are active.  Consider using PDOStatement::fetchAll().  Alternatively, if your code is only ever going to run against mysql, you may enable query buffering by setting the PDO::MYSQL_ATTR_USE_BUFFERED_QUERY attribute. - Invalid query: SELECT RELEASE_LOCK('9495a06cc47a100fd8738872573644ed') AS ci_session_lock
ERROR - 2019-06-21 10:50:23 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/health/dashboard.php 12
ERROR - 2019-06-21 10:51:15 --> Severity: Error --> Allowed memory size of 402653184 bytes exhausted (tried to allocate 16384 bytes) /home/compatl8/public_html/tools/system/database/drivers/pdo/pdo_driver.php 184
ERROR - 2019-06-21 10:51:25 --> Query error: Cannot execute queries while other unbuffered queries are active.  Consider using PDOStatement::fetchAll().  Alternatively, if your code is only ever going to run against mysql, you may enable query buffering by setting the PDO::MYSQL_ATTR_USE_BUFFERED_QUERY attribute. - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1561114285
WHERE `id` = 'd268526ef3c2ec51bbbb9adaab551e2600efeedf'
ERROR - 2019-06-21 10:51:25 --> Severity: Warning --> Unknown: Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-21 10:51:25 --> Query error: Cannot execute queries while other unbuffered queries are active.  Consider using PDOStatement::fetchAll().  Alternatively, if your code is only ever going to run against mysql, you may enable query buffering by setting the PDO::MYSQL_ATTR_USE_BUFFERED_QUERY attribute. - Invalid query: SELECT RELEASE_LOCK('9495a06cc47a100fd8738872573644ed') AS ci_session_lock
ERROR - 2019-06-21 10:55:51 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 10:56:16 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-21 11:02:23 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 11:03:34 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 11:04:04 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 11:04:12 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-21 11:04:49 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 11:05:23 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 11:05:37 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 11:05:57 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 11:06:26 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 11:07:07 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 11:07:44 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 11:08:14 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 11:08:33 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 11:09:06 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 11:09:26 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 11:09:46 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 11:10:14 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 11:10:43 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 11:11:58 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-21 11:18:24 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-21 11:18:25 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-21 11:23:18 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-21 11:26:31 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 11:27:22 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 11:31:06 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-21 11:31:08 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-21 11:31:08 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-21 11:31:08 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-21 11:31:28 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 11:32:01 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 11:32:40 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 11:33:11 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 11:33:39 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 11:34:03 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 11:34:35 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 11:34:54 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 11:35:30 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 11:36:00 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 11:36:45 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 11:37:14 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 11:37:42 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 11:38:03 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 11:43:14 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 11:43:44 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 11:44:57 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 11:46:04 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 11:46:34 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 11:47:02 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 11:47:42 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 11:48:01 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 11:50:40 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 81
ERROR - 2019-06-21 11:50:40 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 82
ERROR - 2019-06-21 11:57:20 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 81
ERROR - 2019-06-21 11:57:20 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 82
ERROR - 2019-06-21 11:59:18 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-21 12:02:01 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 12:04:41 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 12:05:13 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 12:05:50 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 12:06:24 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 12:07:07 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 12:07:47 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 12:08:07 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 12:08:44 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 12:09:08 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 12:09:21 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-21 12:09:50 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 12:10:26 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 12:11:12 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 12:11:48 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 12:12:24 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 12:12:59 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 81
ERROR - 2019-06-21 12:12:59 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 82
ERROR - 2019-06-21 12:13:52 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 12:14:40 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 12:15:20 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 12:16:06 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 12:16:34 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 12:17:28 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 12:18:13 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 12:18:18 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 12:18:50 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 12:19:26 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 12:20:18 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 12:21:07 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 12:21:38 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 12:22:10 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 12:23:16 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 12:24:02 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 12:24:27 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 12:25:04 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 12:25:45 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 12:26:19 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 12:26:44 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 12:27:13 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 12:27:34 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 12:27:48 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 12:28:28 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 12:29:41 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 12:30:09 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 12:30:36 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 12:30:56 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 81
ERROR - 2019-06-21 12:30:56 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 82
ERROR - 2019-06-21 12:31:58 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 12:32:54 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 12:33:25 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 12:34:03 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 12:34:34 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 12:35:06 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 12:35:45 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 12:36:17 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 12:36:50 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 12:37:23 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 12:39:11 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 12:39:55 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 12:40:35 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 12:41:14 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 12:41:32 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 12:42:05 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 12:42:31 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 12:42:57 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 12:43:18 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 12:43:46 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 12:44:12 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 12:44:41 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 12:45:00 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 12:46:04 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 12:46:29 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 12:46:51 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 12:47:17 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 12:47:43 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 12:48:07 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 12:48:32 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 12:48:51 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 12:49:08 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 12:49:40 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 12:50:05 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 12:50:22 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/accountant/dashboard.php 14
ERROR - 2019-06-21 12:55:05 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-21 12:59:17 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-21 16:31:46 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 81
ERROR - 2019-06-21 16:31:46 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 82
ERROR - 2019-06-21 18:55:28 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-21 18:55:59 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-21 18:56:24 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-21 18:56:51 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-21 18:57:55 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-21 21:46:23 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
