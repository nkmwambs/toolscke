<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-06-26 02:14:21 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-26 02:15:33 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-26 02:48:16 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-26 02:49:29 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-26 03:10:13 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-26 03:10:33 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-26 03:10:50 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-26 03:17:22 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-26 03:41:29 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-26 05:37:22 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-26 06:15:00 --> Query error: Column 'userid' cannot be null - Invalid query: INSERT INTO `detail` (`recid`, `userid`, `rson`, `app_name`) VALUES ('1516485', NULL, 'give the breakdown under notes', NULL)
ERROR - 2019-06-26 06:15:25 --> Query error: Column 'userid' cannot be null - Invalid query: INSERT INTO `detail` (`recid`, `userid`, `rson`, `app_name`) VALUES ('1516485', NULL, 'give breakdown under notes', NULL)
ERROR - 2019-06-26 06:15:26 --> Query error: Column 'userid' cannot be null - Invalid query: INSERT INTO `detail` (`recid`, `userid`, `rson`, `app_name`) VALUES ('1516485', NULL, 'give breakdown under notes', NULL)
ERROR - 2019-06-26 06:15:26 --> Query error: Column 'userid' cannot be null - Invalid query: INSERT INTO `detail` (`recid`, `userid`, `rson`, `app_name`) VALUES ('1516485', NULL, 'give breakdown under notes', NULL)
ERROR - 2019-06-26 06:20:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:20:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 06:27:39 --> Query error: Column 'userid' cannot be null - Invalid query: INSERT INTO `detail` (`recid`, `userid`, `rson`, `app_name`) VALUES ('1519015', NULL, 'Just purchase the devotional books for the youth first. If they are effectively using them then you can buy for the family later.', NULL)
ERROR - 2019-06-26 06:28:54 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-26 06:29:12 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-26 06:31:52 --> Query error: Column 'userid' cannot be null - Invalid query: INSERT INTO `detail` (`recid`, `userid`, `rson`, `app_name`) VALUES ('1519047', NULL, 'dont you have wifi? there is unlimitted package going for 3k', NULL)
ERROR - 2019-06-26 06:36:05 --> Query error: Column 'userid' cannot be null - Invalid query: INSERT INTO `detail` (`recid`, `userid`, `rson`, `app_name`) VALUES ('1516485', NULL, 'give breakdown', NULL)
ERROR - 2019-06-26 06:36:23 --> Query error: Column 'userid' cannot be null - Invalid query: INSERT INTO `detail` (`recid`, `userid`, `rson`, `app_name`) VALUES ('1516485', NULL, 'give breakdown for this', NULL)
ERROR - 2019-06-26 06:36:35 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-26 06:36:36 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-26 06:37:16 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-26 06:37:40 --> Query error: Column 'userid' cannot be null - Invalid query: INSERT INTO `detail` (`recid`, `userid`, `rson`, `app_name`) VALUES ('1515947', NULL, 'which brooms are these that go at 40?-', NULL)
ERROR - 2019-06-26 06:42:39 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-26 06:45:59 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-26 06:50:25 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-26 07:21:05 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-06-26 07:22:57 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-06-26 07:25:07 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 81
ERROR - 2019-06-26 07:25:07 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 82
ERROR - 2019-06-26 07:26:36 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-26 07:31:36 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-26 07:38:19 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-26 07:40:19 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-26 07:42:04 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-26 07:43:20 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-26 07:43:34 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-26 07:48:36 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-26 07:51:12 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 07:51:25 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 07:52:21 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 07:52:54 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 07:53:01 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 07:53:13 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 07:53:39 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 07:53:44 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 07:53:58 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 07:53:59 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 07:54:02 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 07:54:07 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 07:54:10 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 07:54:20 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 07:54:20 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 07:54:33 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 07:55:26 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 07:55:54 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 07:56:30 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 07:57:54 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 07:58:59 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 07:59:00 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 07:59:03 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 07:59:07 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 07:59:15 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 08:00:58 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 08:01:05 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 08:01:08 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 08:01:19 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 08:01:27 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 08:01:28 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 08:01:40 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 08:01:55 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 08:02:00 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 08:02:08 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 08:02:13 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 08:02:14 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 08:02:16 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 08:02:17 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 08:02:50 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 08:02:59 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 08:03:00 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 08:03:00 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 08:03:04 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 08:03:09 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 08:03:10 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 08:03:10 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 08:03:10 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 08:03:11 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 08:03:30 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 08:03:37 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 08:04:04 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 08:04:25 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 08:04:26 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 08:04:26 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 08:04:36 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 08:04:37 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 08:04:42 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 08:04:47 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 08:04:49 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 08:04:53 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 08:04:55 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 08:04:56 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-26 08:05:12 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 08:05:16 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 08:05:23 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 08:05:25 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 08:12:39 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 08:13:40 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 08:13:52 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 08:14:31 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 08:15:10 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 08:15:13 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 08:15:41 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 08:15:43 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 08:15:49 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 08:20:02 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-26 08:20:40 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-26 08:21:32 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-26 08:23:15 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-26 08:23:50 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 81
ERROR - 2019-06-26 08:23:50 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 82
ERROR - 2019-06-26 08:24:02 --> 404 Page Not Found: Facilitator/assets
ERROR - 2019-06-26 08:24:36 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-26 08:24:58 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 81
ERROR - 2019-06-26 08:24:58 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 82
ERROR - 2019-06-26 08:26:23 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-26 08:29:46 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-26 08:34:55 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-26 08:35:24 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-26 08:35:44 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-26 08:41:11 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-26 08:49:39 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-26 08:50:32 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-26 08:56:57 --> Query error: Column 'fy' cannot be null - Invalid query: INSERT INTO `planheader` (`icpNo`, `fy`) VALUES ('KE262', NULL)
ERROR - 2019-06-26 08:56:57 --> Query error: Column 'planHeaderID' cannot be null - Invalid query: INSERT INTO `plansschedule` (`planHeaderID`, `AccNo`, `plan_item_tag_id`, `details`, `qty`, `unitCost`, `often`, `totalCost`, `notes`, `month_1_amount`, `month_2_amount`, `month_3_amount`, `month_4_amount`, `month_5_amount`, `month_6_amount`, `month_7_amount`, `month_8_amount`, `month_9_amount`, `month_10_amount`, `month_11_amount`, `month_12_amount`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2019-06-26 09:02:04 --> Query error: Column 'fy' cannot be null - Invalid query: INSERT INTO `planheader` (`icpNo`, `fy`) VALUES ('KE262', NULL)
ERROR - 2019-06-26 09:02:04 --> Query error: Column 'planHeaderID' cannot be null - Invalid query: INSERT INTO `plansschedule` (`planHeaderID`, `AccNo`, `plan_item_tag_id`, `details`, `qty`, `unitCost`, `often`, `totalCost`, `notes`, `month_1_amount`, `month_2_amount`, `month_3_amount`, `month_4_amount`, `month_5_amount`, `month_6_amount`, `month_7_amount`, `month_8_amount`, `month_9_amount`, `month_10_amount`, `month_11_amount`, `month_12_amount`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2019-06-26 09:11:28 --> Query error: Column 'fy' cannot be null - Invalid query: INSERT INTO `planheader` (`icpNo`, `fy`) VALUES ('KE262', NULL)
ERROR - 2019-06-26 09:11:28 --> Query error: Column 'planHeaderID' cannot be null - Invalid query: INSERT INTO `plansschedule` (`planHeaderID`, `AccNo`, `plan_item_tag_id`, `details`, `qty`, `unitCost`, `often`, `totalCost`, `notes`, `month_1_amount`, `month_2_amount`, `month_3_amount`, `month_4_amount`, `month_5_amount`, `month_6_amount`, `month_7_amount`, `month_8_amount`, `month_9_amount`, `month_10_amount`, `month_11_amount`, `month_12_amount`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2019-06-26 09:12:58 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-26 09:31:57 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-26 09:33:23 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-26 09:35:06 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-26 09:40:10 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 09:50:55 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-26 09:50:56 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-26 10:00:03 --> 404 Page Not Found: Civa/assets
ERROR - 2019-06-26 10:21:31 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-26 10:24:39 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-26 10:25:08 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-26 10:25:36 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-26 10:25:59 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-26 10:26:58 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-26 10:56:52 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-26 11:22:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:22:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:22:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:22:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:22:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:22:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:22:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:22:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:22:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:22:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:22:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:22:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:22:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:22:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:22:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:22:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:22:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:22:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:22:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:22:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:22:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:22:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:22:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:22:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:22:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:22:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:22:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:22:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:22:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:22:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:22:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:22:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:22:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:22:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:22:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:22:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:22:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:22:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:22:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:22:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:22:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:22:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:22:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:22:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:22:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:22:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:22:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:22:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:22:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:22:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:22:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:22:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:22:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:22:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:22:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:22:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:22:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:22:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:22:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:26:32 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-26 11:29:17 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-26 11:30:13 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-26 11:33:00 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-26 11:35:28 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-26 11:37:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:37:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 11:40:21 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-26 11:46:32 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-26 11:53:45 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-26 11:55:27 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-26 11:57:32 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-26 12:00:33 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-26 12:02:33 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-26 12:18:32 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-26 12:23:29 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-26 12:25:01 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-26 12:30:00 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-26 12:34:30 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-26 12:35:05 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-26 12:41:24 --> Unable to connect to the database
ERROR - 2019-06-26 12:41:24 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:41:24 --> Unable to connect to the database
ERROR - 2019-06-26 12:41:24 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:41:26 --> Unable to connect to the database
ERROR - 2019-06-26 12:41:26 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:41:27 --> Unable to connect to the database
ERROR - 2019-06-26 12:41:27 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:41:29 --> Unable to connect to the database
ERROR - 2019-06-26 12:41:29 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:41:32 --> Unable to connect to the database
ERROR - 2019-06-26 12:41:32 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:41:35 --> Unable to connect to the database
ERROR - 2019-06-26 12:41:35 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:41:35 --> Unable to connect to the database
ERROR - 2019-06-26 12:41:35 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:41:37 --> Unable to connect to the database
ERROR - 2019-06-26 12:41:37 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:41:40 --> Unable to connect to the database
ERROR - 2019-06-26 12:41:40 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:41:42 --> Unable to connect to the database
ERROR - 2019-06-26 12:41:42 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:41:43 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:41:44 --> Unable to connect to the database
ERROR - 2019-06-26 12:41:44 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:41:44 --> Unable to connect to the database
ERROR - 2019-06-26 12:41:44 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:41:47 --> Unable to connect to the database
ERROR - 2019-06-26 12:41:47 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:41:47 --> Unable to connect to the database
ERROR - 2019-06-26 12:41:47 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:41:48 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:41:52 --> Unable to connect to the database
ERROR - 2019-06-26 12:41:52 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:41:54 --> Unable to connect to the database
ERROR - 2019-06-26 12:41:54 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:41:54 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:41:55 --> Unable to connect to the database
ERROR - 2019-06-26 12:41:55 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:41:57 --> Unable to connect to the database
ERROR - 2019-06-26 12:41:57 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:41:58 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:41:58 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:41:58 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:41:58 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:41:58 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:41:58 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:41:58 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:41:58 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:41:58 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:41:58 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:41:58 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:41:58 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:41:58 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:41:58 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:41:58 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:41:58 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:41:58 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:41:58 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:41:58 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:41:58 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:41:58 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:41:58 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:41:58 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:41:58 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:41:58 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:41:58 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:41:58 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:41:58 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:41:58 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:41:58 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:41:58 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:41:58 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:41:58 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:41:58 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:41:58 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:41:58 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:41:58 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:41:58 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:41:58 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:41:58 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:41:58 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:41:58 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:41:58 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:41:58 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:41:58 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:41:58 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:41:58 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:41:58 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:41:58 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:41:58 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:41:58 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:41:58 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:41:58 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:41:58 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:41:58 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:41:58 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:41:58 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:41:58 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:41:58 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:41:58 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:41:58 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:41:59 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:42:00 --> Unable to connect to the database
ERROR - 2019-06-26 12:42:00 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:42:00 --> Unable to connect to the database
ERROR - 2019-06-26 12:42:00 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:42:00 --> Unable to connect to the database
ERROR - 2019-06-26 12:42:00 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:42:00 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:42:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:01 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:42:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:02 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:02 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:42:02 --> Unable to connect to the database
ERROR - 2019-06-26 12:42:02 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:42:04 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:42:05 --> Unable to connect to the database
ERROR - 2019-06-26 12:42:05 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:42:06 --> Unable to connect to the database
ERROR - 2019-06-26 12:42:06 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:42:07 --> Unable to connect to the database
ERROR - 2019-06-26 12:42:07 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:42:07 --> Unable to connect to the database
ERROR - 2019-06-26 12:42:07 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:42:08 --> Unable to connect to the database
ERROR - 2019-06-26 12:42:08 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:42:10 --> Unable to connect to the database
ERROR - 2019-06-26 12:42:10 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:42:10 --> Unable to connect to the database
ERROR - 2019-06-26 12:42:10 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:42:11 --> Unable to connect to the database
ERROR - 2019-06-26 12:42:11 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:42:12 --> Unable to connect to the database
ERROR - 2019-06-26 12:42:12 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:42:12 --> Unable to connect to the database
ERROR - 2019-06-26 12:42:12 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:42:13 --> Unable to connect to the database
ERROR - 2019-06-26 12:42:13 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:42:13 --> Unable to connect to the database
ERROR - 2019-06-26 12:42:13 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:42:14 --> Unable to connect to the database
ERROR - 2019-06-26 12:42:14 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:42:15 --> Unable to connect to the database
ERROR - 2019-06-26 12:42:15 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:42:15 --> Unable to connect to the database
ERROR - 2019-06-26 12:42:15 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:42:16 --> Unable to connect to the database
ERROR - 2019-06-26 12:42:16 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:42:18 --> Unable to connect to the database
ERROR - 2019-06-26 12:42:18 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:42:18 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:42:19 --> Unable to connect to the database
ERROR - 2019-06-26 12:42:19 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:42:19 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:42:20 --> Unable to connect to the database
ERROR - 2019-06-26 12:42:20 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:42:20 --> Unable to connect to the database
ERROR - 2019-06-26 12:42:20 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:42:22 --> Unable to connect to the database
ERROR - 2019-06-26 12:42:22 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:42:25 --> Unable to connect to the database
ERROR - 2019-06-26 12:42:25 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:42:25 --> Unable to connect to the database
ERROR - 2019-06-26 12:42:25 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:42:25 --> Unable to connect to the database
ERROR - 2019-06-26 12:42:25 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:42:26 --> Unable to connect to the database
ERROR - 2019-06-26 12:42:26 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:42:29 --> Unable to connect to the database
ERROR - 2019-06-26 12:42:29 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:42:30 --> Unable to connect to the database
ERROR - 2019-06-26 12:42:30 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:42:30 --> Unable to connect to the database
ERROR - 2019-06-26 12:42:30 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:42:35 --> Unable to connect to the database
ERROR - 2019-06-26 12:42:35 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:42:35 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:42:35 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:42:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:36 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:36 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:42:38 --> Unable to connect to the database
ERROR - 2019-06-26 12:42:38 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:42:39 --> Unable to connect to the database
ERROR - 2019-06-26 12:42:39 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:42:40 --> Unable to connect to the database
ERROR - 2019-06-26 12:42:40 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:42:41 --> Unable to connect to the database
ERROR - 2019-06-26 12:42:41 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:42:42 --> Unable to connect to the database
ERROR - 2019-06-26 12:42:42 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:42:44 --> Unable to connect to the database
ERROR - 2019-06-26 12:42:44 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:42:45 --> Unable to connect to the database
ERROR - 2019-06-26 12:42:45 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:42:46 --> Unable to connect to the database
ERROR - 2019-06-26 12:42:46 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:42:46 --> Unable to connect to the database
ERROR - 2019-06-26 12:42:46 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:42:48 --> Unable to connect to the database
ERROR - 2019-06-26 12:42:48 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:42:48 --> Unable to connect to the database
ERROR - 2019-06-26 12:42:48 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:42:51 --> Unable to connect to the database
ERROR - 2019-06-26 12:42:51 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:42:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:42:52 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:42:53 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:42:57 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:43:00 --> Unable to connect to the database
ERROR - 2019-06-26 12:43:00 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:43:01 --> Unable to connect to the database
ERROR - 2019-06-26 12:43:01 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:43:01 --> Unable to connect to the database
ERROR - 2019-06-26 12:43:01 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:43:01 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:43:02 --> Unable to connect to the database
ERROR - 2019-06-26 12:43:02 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:43:02 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:43:02 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:43:03 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:43:07 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:43:10 --> Unable to connect to the database
ERROR - 2019-06-26 12:43:10 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:43:13 --> Unable to connect to the database
ERROR - 2019-06-26 12:43:13 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:43:13 --> Unable to connect to the database
ERROR - 2019-06-26 12:43:13 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:43:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:16 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:43:19 --> Unable to connect to the database
ERROR - 2019-06-26 12:43:19 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:43:20 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:43:21 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:43:21 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:43:24 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:43:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:27 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:43:28 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:43:32 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:43:33 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:43:38 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:43:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:43:40 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:43:48 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:43:50 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:43:51 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:43:51 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:43:53 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:43:54 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:44:03 --> Unable to connect to the database
ERROR - 2019-06-26 12:44:03 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:44:11 --> Unable to connect to the database
ERROR - 2019-06-26 12:44:11 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:44:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:12 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:44:14 --> Unable to connect to the database
ERROR - 2019-06-26 12:44:14 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:44:18 --> Unable to connect to the database
ERROR - 2019-06-26 12:44:18 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:44:20 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:44:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:22 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:44:22 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:44:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:26 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:44:33 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:33 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:33 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:33 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:33 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:33 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:33 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:33 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:33 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:33 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:33 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:33 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:33 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:33 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:33 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:33 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:33 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:33 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:33 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:33 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:33 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:33 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:33 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:33 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:33 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:33 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:33 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:33 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:33 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:33 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:33 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:33 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:33 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:33 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:33 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:33 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:33 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:33 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:33 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:33 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:33 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:33 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:33 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:33 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:33 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:33 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:33 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:33 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:33 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:33 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:33 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:33 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:33 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:33 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:33 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:33 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:33 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:33 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:33 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:33 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:44:35 --> Unable to connect to the database
ERROR - 2019-06-26 12:44:35 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:44:40 --> Unable to connect to the database
ERROR - 2019-06-26 12:44:40 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:44:41 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:44:43 --> Unable to connect to the database
ERROR - 2019-06-26 12:44:43 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:44:45 --> Unable to connect to the database
ERROR - 2019-06-26 12:44:45 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:44:47 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:44:52 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:44:57 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:44:58 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:45:02 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:45:05 --> Unable to connect to the database
ERROR - 2019-06-26 12:45:05 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:45:05 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:45:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:06 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:45:09 --> Unable to connect to the database
ERROR - 2019-06-26 12:45:09 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:45:14 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:45:15 --> Unable to connect to the database
ERROR - 2019-06-26 12:45:15 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:45:17 --> Unable to connect to the database
ERROR - 2019-06-26 12:45:17 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:45:18 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:45:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:21 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:45:22 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:45:26 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:45:30 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:45:33 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:45:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:39 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:45:41 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:45:42 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:45:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:45:44 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:45:55 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:45:57 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:46:07 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:46:07 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:46:08 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:46:14 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:46:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:46:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:46:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:46:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:46:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:46:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:46:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:46:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:46:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:46:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:46:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:46:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:46:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:46:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:46:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:46:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:46:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:46:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:46:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:46:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:46:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:46:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:46:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:46:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:46:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:46:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:46:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:46:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:46:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:46:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:46:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:46:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:46:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:46:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:46:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:46:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:46:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:46:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:46:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:46:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:46:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:46:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:46:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:46:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:46:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:46:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:46:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:46:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:46:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:46:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:46:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:46:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:46:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:46:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:46:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:46:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:46:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:46:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:46:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:46:14 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:46:26 --> Unable to connect to the database
ERROR - 2019-06-26 12:46:26 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:46:30 --> Unable to connect to the database
ERROR - 2019-06-26 12:46:30 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:46:33 --> Unable to connect to the database
ERROR - 2019-06-26 12:46:33 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:46:41 --> Unable to connect to the database
ERROR - 2019-06-26 12:46:41 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:46:43 --> Unable to connect to the database
ERROR - 2019-06-26 12:46:43 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:46:43 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:46:47 --> Unable to connect to the database
ERROR - 2019-06-26 12:46:47 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:46:50 --> Unable to connect to the database
ERROR - 2019-06-26 12:46:50 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:46:54 --> Unable to connect to the database
ERROR - 2019-06-26 12:46:54 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:46:55 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:46:59 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:46:59 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:47:01 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:47:01 --> Unable to connect to the database
ERROR - 2019-06-26 12:47:01 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:47:01 --> Unable to connect to the database
ERROR - 2019-06-26 12:47:01 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:47:02 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:47:04 --> Unable to connect to the database
ERROR - 2019-06-26 12:47:04 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:47:05 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:47:05 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:47:16 --> Unable to connect to the database
ERROR - 2019-06-26 12:47:16 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:47:17 --> Unable to connect to the database
ERROR - 2019-06-26 12:47:17 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:47:19 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:47:20 --> Unable to connect to the database
ERROR - 2019-06-26 12:47:20 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:47:21 --> Unable to connect to the database
ERROR - 2019-06-26 12:47:21 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:47:23 --> Unable to connect to the database
ERROR - 2019-06-26 12:47:23 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:47:24 --> Unable to connect to the database
ERROR - 2019-06-26 12:47:24 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:47:27 --> Unable to connect to the database
ERROR - 2019-06-26 12:47:27 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:47:28 --> Unable to connect to the database
ERROR - 2019-06-26 12:47:28 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:47:29 --> Unable to connect to the database
ERROR - 2019-06-26 12:47:29 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:47:31 --> Unable to connect to the database
ERROR - 2019-06-26 12:47:31 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:47:32 --> Unable to connect to the database
ERROR - 2019-06-26 12:47:32 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:47:33 --> Unable to connect to the database
ERROR - 2019-06-26 12:47:33 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:47:35 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:47:36 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:47:38 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:47:42 --> Unable to connect to the database
ERROR - 2019-06-26 12:47:42 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:47:43 --> Unable to connect to the database
ERROR - 2019-06-26 12:47:43 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:47:46 --> Unable to connect to the database
ERROR - 2019-06-26 12:47:46 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:47:46 --> Unable to connect to the database
ERROR - 2019-06-26 12:47:46 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:47:52 --> Unable to connect to the database
ERROR - 2019-06-26 12:47:52 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:47:54 --> Unable to connect to the database
ERROR - 2019-06-26 12:47:54 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:47:54 --> Unable to connect to the database
ERROR - 2019-06-26 12:47:54 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:47:54 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:47:58 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:48:01 --> Unable to connect to the database
ERROR - 2019-06-26 12:48:01 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:48:04 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:48:06 --> Unable to connect to the database
ERROR - 2019-06-26 12:48:06 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:48:09 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:48:13 --> Unable to connect to the database
ERROR - 2019-06-26 12:48:13 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:48:15 --> Unable to connect to the database
ERROR - 2019-06-26 12:48:15 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:48:17 --> Unable to connect to the database
ERROR - 2019-06-26 12:48:17 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:48:20 --> Unable to connect to the database
ERROR - 2019-06-26 12:48:20 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:48:20 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:48:21 --> Unable to connect to the database
ERROR - 2019-06-26 12:48:21 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:48:22 --> Unable to connect to the database
ERROR - 2019-06-26 12:48:22 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:48:26 --> Unable to connect to the database
ERROR - 2019-06-26 12:48:26 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:48:28 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:48:37 --> Unable to connect to the database
ERROR - 2019-06-26 12:48:37 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:48:39 --> Unable to connect to the database
ERROR - 2019-06-26 12:48:39 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:48:42 --> Unable to connect to the database
ERROR - 2019-06-26 12:48:42 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:48:45 --> Unable to connect to the database
ERROR - 2019-06-26 12:48:45 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:48:45 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:48:48 --> Unable to connect to the database
ERROR - 2019-06-26 12:48:48 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:48:53 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:48:55 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:48:55 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:49:09 --> Unable to connect to the database
ERROR - 2019-06-26 12:49:09 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:49:10 --> Unable to connect to the database
ERROR - 2019-06-26 12:49:10 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:49:12 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:49:13 --> Unable to connect to the database
ERROR - 2019-06-26 12:49:13 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:49:15 --> Unable to connect to the database
ERROR - 2019-06-26 12:49:15 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:49:15 --> Unable to connect to the database
ERROR - 2019-06-26 12:49:15 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:49:23 --> Unable to connect to the database
ERROR - 2019-06-26 12:49:23 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:49:25 --> Unable to connect to the database
ERROR - 2019-06-26 12:49:25 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:49:25 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:49:25 --> Unable to connect to the database
ERROR - 2019-06-26 12:49:25 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:49:27 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:49:28 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:49:29 --> Unable to connect to the database
ERROR - 2019-06-26 12:49:29 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:49:31 --> Unable to connect to the database
ERROR - 2019-06-26 12:49:31 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:49:32 --> Unable to connect to the database
ERROR - 2019-06-26 12:49:32 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:49:32 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:49:32 --> Unable to connect to the database
ERROR - 2019-06-26 12:49:32 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:49:34 --> Unable to connect to the database
ERROR - 2019-06-26 12:49:34 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:49:34 --> Unable to connect to the database
ERROR - 2019-06-26 12:49:34 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:49:35 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:49:36 --> Unable to connect to the database
ERROR - 2019-06-26 12:49:36 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:49:37 --> Unable to connect to the database
ERROR - 2019-06-26 12:49:37 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:49:38 --> Unable to connect to the database
ERROR - 2019-06-26 12:49:38 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:49:39 --> Unable to connect to the database
ERROR - 2019-06-26 12:49:39 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:49:39 --> Unable to connect to the database
ERROR - 2019-06-26 12:49:39 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:49:41 --> Unable to connect to the database
ERROR - 2019-06-26 12:49:41 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:49:43 --> Unable to connect to the database
ERROR - 2019-06-26 12:49:43 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:49:43 --> Unable to connect to the database
ERROR - 2019-06-26 12:49:43 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:49:44 --> Unable to connect to the database
ERROR - 2019-06-26 12:49:44 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:49:45 --> Unable to connect to the database
ERROR - 2019-06-26 12:49:45 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:49:46 --> Unable to connect to the database
ERROR - 2019-06-26 12:49:46 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:49:46 --> Unable to connect to the database
ERROR - 2019-06-26 12:49:46 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:49:47 --> Unable to connect to the database
ERROR - 2019-06-26 12:49:47 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:49:49 --> Unable to connect to the database
ERROR - 2019-06-26 12:49:49 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:49:49 --> Unable to connect to the database
ERROR - 2019-06-26 12:49:49 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:49:50 --> Unable to connect to the database
ERROR - 2019-06-26 12:49:50 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:49:51 --> Unable to connect to the database
ERROR - 2019-06-26 12:49:51 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:49:52 --> Unable to connect to the database
ERROR - 2019-06-26 12:49:52 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:49:52 --> Unable to connect to the database
ERROR - 2019-06-26 12:49:52 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:49:52 --> Unable to connect to the database
ERROR - 2019-06-26 12:49:52 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:49:52 --> Unable to connect to the database
ERROR - 2019-06-26 12:49:52 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:49:53 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:49:55 --> Unable to connect to the database
ERROR - 2019-06-26 12:49:55 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:49:55 --> Unable to connect to the database
ERROR - 2019-06-26 12:49:55 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:49:56 --> Unable to connect to the database
ERROR - 2019-06-26 12:49:56 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:49:57 --> Unable to connect to the database
ERROR - 2019-06-26 12:49:57 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:49:57 --> Unable to connect to the database
ERROR - 2019-06-26 12:49:57 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:49:57 --> Unable to connect to the database
ERROR - 2019-06-26 12:49:57 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:49:58 --> Unable to connect to the database
ERROR - 2019-06-26 12:49:58 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:49:59 --> Unable to connect to the database
ERROR - 2019-06-26 12:49:59 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:50:02 --> Unable to connect to the database
ERROR - 2019-06-26 12:50:02 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:50:03 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:50:05 --> Unable to connect to the database
ERROR - 2019-06-26 12:50:05 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:50:07 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:50:10 --> Unable to connect to the database
ERROR - 2019-06-26 12:50:10 --> Unable to connect to the database
ERROR - 2019-06-26 12:50:10 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:50:10 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:50:12 --> Unable to connect to the database
ERROR - 2019-06-26 12:50:12 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:50:12 --> Unable to connect to the database
ERROR - 2019-06-26 12:50:12 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:50:18 --> Unable to connect to the database
ERROR - 2019-06-26 12:50:18 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:50:18 --> Unable to connect to the database
ERROR - 2019-06-26 12:50:18 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:50:19 --> Unable to connect to the database
ERROR - 2019-06-26 12:50:19 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:50:19 --> Unable to connect to the database
ERROR - 2019-06-26 12:50:19 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:50:23 --> Unable to connect to the database
ERROR - 2019-06-26 12:50:23 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:50:23 --> Unable to connect to the database
ERROR - 2019-06-26 12:50:23 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:50:23 --> Unable to connect to the database
ERROR - 2019-06-26 12:50:23 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:50:23 --> Unable to connect to the database
ERROR - 2019-06-26 12:50:23 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:50:30 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:50:31 --> Unable to connect to the database
ERROR - 2019-06-26 12:50:31 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:50:32 --> Unable to connect to the database
ERROR - 2019-06-26 12:50:32 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:50:32 --> Unable to connect to the database
ERROR - 2019-06-26 12:50:32 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:50:33 --> Unable to connect to the database
ERROR - 2019-06-26 12:50:33 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:50:35 --> Unable to connect to the database
ERROR - 2019-06-26 12:50:35 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:50:39 --> Unable to connect to the database
ERROR - 2019-06-26 12:50:39 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:50:39 --> Unable to connect to the database
ERROR - 2019-06-26 12:50:39 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:50:44 --> Unable to connect to the database
ERROR - 2019-06-26 12:50:44 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:50:46 --> Unable to connect to the database
ERROR - 2019-06-26 12:50:46 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:50:49 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:50:51 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:50:58 --> Unable to connect to the database
ERROR - 2019-06-26 12:50:58 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:50:59 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:51:01 --> Unable to connect to the database
ERROR - 2019-06-26 12:51:01 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:51:04 --> Unable to connect to the database
ERROR - 2019-06-26 12:51:04 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:51:07 --> Unable to connect to the database
ERROR - 2019-06-26 12:51:07 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:51:08 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:51:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:51:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:51:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:51:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:51:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:51:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:51:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:51:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:51:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:51:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:51:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:51:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:51:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:51:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:51:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:51:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:51:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:51:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:51:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:51:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:51:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:51:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:51:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:51:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:51:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:51:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:51:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:51:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:51:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:51:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:51:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:51:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:51:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:51:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:51:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:51:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:51:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:51:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:51:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:51:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:51:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:51:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:51:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:51:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:51:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:51:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:51:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:51:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:51:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:51:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:51:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:51:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:51:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:51:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:51:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:51:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:51:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:51:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:51:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 12:51:12 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:51:13 --> Unable to connect to the database
ERROR - 2019-06-26 12:51:13 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:51:15 --> Unable to connect to the database
ERROR - 2019-06-26 12:51:15 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:51:18 --> Unable to connect to the database
ERROR - 2019-06-26 12:51:18 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:51:20 --> Unable to connect to the database
ERROR - 2019-06-26 12:51:20 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:51:20 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:51:22 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:51:24 --> Unable to connect to the database
ERROR - 2019-06-26 12:51:24 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:51:32 --> Unable to connect to the database
ERROR - 2019-06-26 12:51:32 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:51:32 --> Unable to connect to the database
ERROR - 2019-06-26 12:51:32 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:51:33 --> Unable to connect to the database
ERROR - 2019-06-26 12:51:33 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:51:34 --> Unable to connect to the database
ERROR - 2019-06-26 12:51:34 --> Unable to connect to the database
ERROR - 2019-06-26 12:51:34 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:51:34 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:51:35 --> Unable to connect to the database
ERROR - 2019-06-26 12:51:35 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:51:42 --> Unable to connect to the database
ERROR - 2019-06-26 12:51:42 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:51:43 --> Unable to connect to the database
ERROR - 2019-06-26 12:51:43 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:51:46 --> Unable to connect to the database
ERROR - 2019-06-26 12:51:46 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:51:53 --> Unable to connect to the database
ERROR - 2019-06-26 12:51:53 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:51:55 --> Unable to connect to the database
ERROR - 2019-06-26 12:51:55 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:51:56 --> Unable to connect to the database
ERROR - 2019-06-26 12:51:56 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:51:59 --> Unable to connect to the database
ERROR - 2019-06-26 12:51:59 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:51:59 --> Unable to connect to the database
ERROR - 2019-06-26 12:51:59 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:52:00 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:52:02 --> Unable to connect to the database
ERROR - 2019-06-26 12:52:02 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:52:07 --> Unable to connect to the database
ERROR - 2019-06-26 12:52:07 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:52:07 --> Unable to connect to the database
ERROR - 2019-06-26 12:52:07 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:52:15 --> Unable to connect to the database
ERROR - 2019-06-26 12:52:15 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:52:18 --> Unable to connect to the database
ERROR - 2019-06-26 12:52:18 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:52:19 --> Unable to connect to the database
ERROR - 2019-06-26 12:52:19 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:52:23 --> Unable to connect to the database
ERROR - 2019-06-26 12:52:23 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:52:31 --> Unable to connect to the database
ERROR - 2019-06-26 12:52:31 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:52:38 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:52:40 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:52:55 --> Unable to connect to the database
ERROR - 2019-06-26 12:52:55 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:52:57 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:52:59 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:53:02 --> Unable to connect to the database
ERROR - 2019-06-26 12:53:02 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:53:10 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:53:11 --> Unable to connect to the database
ERROR - 2019-06-26 12:53:11 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:53:17 --> Unable to connect to the database
ERROR - 2019-06-26 12:53:17 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:53:21 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:53:28 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:53:33 --> Unable to connect to the database
ERROR - 2019-06-26 12:53:33 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:53:34 --> Unable to connect to the database
ERROR - 2019-06-26 12:53:34 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:53:34 --> Unable to connect to the database
ERROR - 2019-06-26 12:53:34 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:53:48 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:53:51 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:53:54 --> Unable to connect to the database
ERROR - 2019-06-26 12:53:54 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:54:00 --> Unable to connect to the database
ERROR - 2019-06-26 12:54:00 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:54:00 --> Unable to connect to the database
ERROR - 2019-06-26 12:54:00 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:54:01 --> Unable to connect to the database
ERROR - 2019-06-26 12:54:01 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:54:04 --> Unable to connect to the database
ERROR - 2019-06-26 12:54:04 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:54:05 --> Unable to connect to the database
ERROR - 2019-06-26 12:54:05 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:54:06 --> Unable to connect to the database
ERROR - 2019-06-26 12:54:06 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:54:07 --> Unable to connect to the database
ERROR - 2019-06-26 12:54:07 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:54:07 --> Unable to connect to the database
ERROR - 2019-06-26 12:54:07 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:54:09 --> Unable to connect to the database
ERROR - 2019-06-26 12:54:09 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:54:12 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:54:24 --> Unable to connect to the database
ERROR - 2019-06-26 12:54:24 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:54:25 --> Unable to connect to the database
ERROR - 2019-06-26 12:54:25 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:54:28 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:54:37 --> Unable to connect to the database
ERROR - 2019-06-26 12:54:37 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:54:41 --> Unable to connect to the database
ERROR - 2019-06-26 12:54:41 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:54:43 --> Unable to connect to the database
ERROR - 2019-06-26 12:54:43 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:54:43 --> Unable to connect to the database
ERROR - 2019-06-26 12:54:43 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:54:47 --> Unable to connect to the database
ERROR - 2019-06-26 12:54:47 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:54:50 --> Unable to connect to the database
ERROR - 2019-06-26 12:54:50 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:54:53 --> Unable to connect to the database
ERROR - 2019-06-26 12:54:53 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:54:53 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:54:54 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:55:04 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:55:09 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:55:13 --> Unable to connect to the database
ERROR - 2019-06-26 12:55:13 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:55:15 --> Unable to connect to the database
ERROR - 2019-06-26 12:55:15 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:55:29 --> Unable to connect to the database
ERROR - 2019-06-26 12:55:29 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:55:33 --> Unable to connect to the database
ERROR - 2019-06-26 12:55:33 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:55:43 --> Unable to connect to the database
ERROR - 2019-06-26 12:55:43 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:55:45 --> Unable to connect to the database
ERROR - 2019-06-26 12:55:45 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:55:49 --> Unable to connect to the database
ERROR - 2019-06-26 12:55:49 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:55:53 --> Unable to connect to the database
ERROR - 2019-06-26 12:55:53 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:55:57 --> Unable to connect to the database
ERROR - 2019-06-26 12:55:57 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:55:59 --> Unable to connect to the database
ERROR - 2019-06-26 12:55:59 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:56:00 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:56:03 --> Unable to connect to the database
ERROR - 2019-06-26 12:56:03 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:56:07 --> Unable to connect to the database
ERROR - 2019-06-26 12:56:07 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:56:08 --> Unable to connect to the database
ERROR - 2019-06-26 12:56:08 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:56:09 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:56:15 --> Unable to connect to the database
ERROR - 2019-06-26 12:56:15 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:56:17 --> Unable to connect to the database
ERROR - 2019-06-26 12:56:17 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:56:26 --> Unable to connect to the database
ERROR - 2019-06-26 12:56:26 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:56:30 --> Unable to connect to the database
ERROR - 2019-06-26 12:56:30 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:56:30 --> Unable to connect to the database
ERROR - 2019-06-26 12:56:30 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:56:34 --> Unable to connect to the database
ERROR - 2019-06-26 12:56:34 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:56:38 --> Unable to connect to the database
ERROR - 2019-06-26 12:56:38 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:56:42 --> Unable to connect to the database
ERROR - 2019-06-26 12:56:42 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:56:45 --> Unable to connect to the database
ERROR - 2019-06-26 12:56:45 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:56:45 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:56:50 --> Unable to connect to the database
ERROR - 2019-06-26 12:56:50 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:56:54 --> Unable to connect to the database
ERROR - 2019-06-26 12:56:54 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:56:55 --> Unable to connect to the database
ERROR - 2019-06-26 12:56:55 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:56:57 --> Unable to connect to the database
ERROR - 2019-06-26 12:56:57 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:56:59 --> Unable to connect to the database
ERROR - 2019-06-26 12:56:59 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:57:02 --> Unable to connect to the database
ERROR - 2019-06-26 12:57:02 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:57:03 --> Unable to connect to the database
ERROR - 2019-06-26 12:57:03 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:57:09 --> Unable to connect to the database
ERROR - 2019-06-26 12:57:09 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:57:13 --> Unable to connect to the database
ERROR - 2019-06-26 12:57:13 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:57:15 --> Unable to connect to the database
ERROR - 2019-06-26 12:57:15 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:57:20 --> Unable to connect to the database
ERROR - 2019-06-26 12:57:20 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:57:20 --> Unable to connect to the database
ERROR - 2019-06-26 12:57:20 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:57:28 --> Unable to connect to the database
ERROR - 2019-06-26 12:57:28 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:57:29 --> Unable to connect to the database
ERROR - 2019-06-26 12:57:29 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:57:31 --> Unable to connect to the database
ERROR - 2019-06-26 12:57:31 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:57:31 --> Unable to connect to the database
ERROR - 2019-06-26 12:57:31 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:57:34 --> Unable to connect to the database
ERROR - 2019-06-26 12:57:34 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:57:41 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:57:47 --> Unable to connect to the database
ERROR - 2019-06-26 12:57:47 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:57:53 --> Unable to connect to the database
ERROR - 2019-06-26 12:57:53 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:57:55 --> Unable to connect to the database
ERROR - 2019-06-26 12:57:55 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:58:00 --> Unable to connect to the database
ERROR - 2019-06-26 12:58:00 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:58:01 --> Unable to connect to the database
ERROR - 2019-06-26 12:58:01 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:58:01 --> Unable to connect to the database
ERROR - 2019-06-26 12:58:01 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:58:03 --> Unable to connect to the database
ERROR - 2019-06-26 12:58:03 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:58:05 --> Unable to connect to the database
ERROR - 2019-06-26 12:58:05 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:58:06 --> Unable to connect to the database
ERROR - 2019-06-26 12:58:06 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:58:07 --> Unable to connect to the database
ERROR - 2019-06-26 12:58:07 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:58:08 --> Unable to connect to the database
ERROR - 2019-06-26 12:58:08 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:58:10 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:58:11 --> Unable to connect to the database
ERROR - 2019-06-26 12:58:11 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:58:12 --> Unable to connect to the database
ERROR - 2019-06-26 12:58:12 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:58:18 --> Unable to connect to the database
ERROR - 2019-06-26 12:58:18 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:58:19 --> Unable to connect to the database
ERROR - 2019-06-26 12:58:19 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:58:22 --> Unable to connect to the database
ERROR - 2019-06-26 12:58:22 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:58:28 --> Unable to connect to the database
ERROR - 2019-06-26 12:58:28 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:58:34 --> Unable to connect to the database
ERROR - 2019-06-26 12:58:34 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:58:37 --> Unable to connect to the database
ERROR - 2019-06-26 12:58:37 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:58:40 --> Unable to connect to the database
ERROR - 2019-06-26 12:58:40 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:58:45 --> Unable to connect to the database
ERROR - 2019-06-26 12:58:45 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:58:45 --> Unable to connect to the database
ERROR - 2019-06-26 12:58:45 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:58:48 --> Unable to connect to the database
ERROR - 2019-06-26 12:58:48 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:58:49 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:58:52 --> Unable to connect to the database
ERROR - 2019-06-26 12:58:52 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:58:56 --> Unable to connect to the database
ERROR - 2019-06-26 12:58:56 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:59:00 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:59:03 --> Unable to connect to the database
ERROR - 2019-06-26 12:59:03 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:59:05 --> Unable to connect to the database
ERROR - 2019-06-26 12:59:05 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:59:08 --> Unable to connect to the database
ERROR - 2019-06-26 12:59:08 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:59:09 --> Unable to connect to the database
ERROR - 2019-06-26 12:59:09 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:59:13 --> Unable to connect to the database
ERROR - 2019-06-26 12:59:13 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:59:17 --> Unable to connect to the database
ERROR - 2019-06-26 12:59:17 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:59:19 --> Unable to connect to the database
ERROR - 2019-06-26 12:59:19 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:59:20 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 12:59:42 --> Unable to connect to the database
ERROR - 2019-06-26 12:59:42 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:59:46 --> Unable to connect to the database
ERROR - 2019-06-26 12:59:46 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:59:47 --> Unable to connect to the database
ERROR - 2019-06-26 12:59:47 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 12:59:54 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 13:00:02 --> Unable to connect to the database
ERROR - 2019-06-26 13:00:02 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:00:11 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 13:00:14 --> Unable to connect to the database
ERROR - 2019-06-26 13:00:14 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:00:18 --> Unable to connect to the database
ERROR - 2019-06-26 13:00:18 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:00:19 --> Unable to connect to the database
ERROR - 2019-06-26 13:00:19 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:00:20 --> Unable to connect to the database
ERROR - 2019-06-26 13:00:20 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:00:23 --> Unable to connect to the database
ERROR - 2019-06-26 13:00:23 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:00:27 --> Unable to connect to the database
ERROR - 2019-06-26 13:00:27 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:00:28 --> Unable to connect to the database
ERROR - 2019-06-26 13:00:28 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:00:33 --> Unable to connect to the database
ERROR - 2019-06-26 13:00:33 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:00:33 --> Unable to connect to the database
ERROR - 2019-06-26 13:00:33 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:00:34 --> Unable to connect to the database
ERROR - 2019-06-26 13:00:34 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:00:35 --> Unable to connect to the database
ERROR - 2019-06-26 13:00:35 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:00:43 --> Unable to connect to the database
ERROR - 2019-06-26 13:00:44 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:00:44 --> Unable to connect to the database
ERROR - 2019-06-26 13:00:44 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:00:50 --> Unable to connect to the database
ERROR - 2019-06-26 13:00:50 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:00:57 --> Unable to connect to the database
ERROR - 2019-06-26 13:00:57 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:00:58 --> Unable to connect to the database
ERROR - 2019-06-26 13:00:58 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:01:02 --> Unable to connect to the database
ERROR - 2019-06-26 13:01:02 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:01:02 --> Unable to connect to the database
ERROR - 2019-06-26 13:01:02 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:01:04 --> Unable to connect to the database
ERROR - 2019-06-26 13:01:04 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:01:05 --> Unable to connect to the database
ERROR - 2019-06-26 13:01:05 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:01:07 --> Unable to connect to the database
ERROR - 2019-06-26 13:01:07 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:01:10 --> Unable to connect to the database
ERROR - 2019-06-26 13:01:10 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:01:10 --> Unable to connect to the database
ERROR - 2019-06-26 13:01:10 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:01:11 --> Unable to connect to the database
ERROR - 2019-06-26 13:01:11 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:01:12 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 13:01:22 --> Unable to connect to the database
ERROR - 2019-06-26 13:01:22 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:01:24 --> Unable to connect to the database
ERROR - 2019-06-26 13:01:24 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:01:25 --> Unable to connect to the database
ERROR - 2019-06-26 13:01:25 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:01:26 --> Unable to connect to the database
ERROR - 2019-06-26 13:01:26 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:01:27 --> Unable to connect to the database
ERROR - 2019-06-26 13:01:27 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:01:29 --> Unable to connect to the database
ERROR - 2019-06-26 13:01:29 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:01:31 --> Unable to connect to the database
ERROR - 2019-06-26 13:01:31 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:01:31 --> Unable to connect to the database
ERROR - 2019-06-26 13:01:31 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:01:31 --> Unable to connect to the database
ERROR - 2019-06-26 13:01:31 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:01:33 --> Unable to connect to the database
ERROR - 2019-06-26 13:01:33 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:01:34 --> Unable to connect to the database
ERROR - 2019-06-26 13:01:34 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:01:36 --> Unable to connect to the database
ERROR - 2019-06-26 13:01:36 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:01:38 --> Unable to connect to the database
ERROR - 2019-06-26 13:01:38 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:01:41 --> Unable to connect to the database
ERROR - 2019-06-26 13:01:41 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:01:42 --> Unable to connect to the database
ERROR - 2019-06-26 13:01:42 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:01:42 --> Unable to connect to the database
ERROR - 2019-06-26 13:01:42 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:01:46 --> Unable to connect to the database
ERROR - 2019-06-26 13:01:46 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:01:46 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 13:01:48 --> Unable to connect to the database
ERROR - 2019-06-26 13:01:48 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:01:54 --> Unable to connect to the database
ERROR - 2019-06-26 13:01:54 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:01:55 --> Unable to connect to the database
ERROR - 2019-06-26 13:01:55 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:02:02 --> Unable to connect to the database
ERROR - 2019-06-26 13:02:02 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:02:05 --> Unable to connect to the database
ERROR - 2019-06-26 13:02:05 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:02:06 --> Unable to connect to the database
ERROR - 2019-06-26 13:02:06 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:02:07 --> Unable to connect to the database
ERROR - 2019-06-26 13:02:07 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:02:11 --> Unable to connect to the database
ERROR - 2019-06-26 13:02:11 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:02:14 --> Unable to connect to the database
ERROR - 2019-06-26 13:02:14 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:02:15 --> Unable to connect to the database
ERROR - 2019-06-26 13:02:15 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:02:16 --> Unable to connect to the database
ERROR - 2019-06-26 13:02:16 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:02:20 --> Unable to connect to the database
ERROR - 2019-06-26 13:02:20 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:02:23 --> Unable to connect to the database
ERROR - 2019-06-26 13:02:23 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:02:30 --> Unable to connect to the database
ERROR - 2019-06-26 13:02:30 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:02:30 --> Unable to connect to the database
ERROR - 2019-06-26 13:02:30 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:02:32 --> Unable to connect to the database
ERROR - 2019-06-26 13:02:32 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:02:38 --> Unable to connect to the database
ERROR - 2019-06-26 13:02:38 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:02:39 --> Unable to connect to the database
ERROR - 2019-06-26 13:02:39 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:02:39 --> Unable to connect to the database
ERROR - 2019-06-26 13:02:39 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:02:40 --> Unable to connect to the database
ERROR - 2019-06-26 13:02:40 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:02:42 --> Unable to connect to the database
ERROR - 2019-06-26 13:02:42 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:02:42 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 13:02:50 --> Unable to connect to the database
ERROR - 2019-06-26 13:02:50 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:02:55 --> Unable to connect to the database
ERROR - 2019-06-26 13:02:55 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:02:56 --> Unable to connect to the database
ERROR - 2019-06-26 13:02:56 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:02:57 --> Unable to connect to the database
ERROR - 2019-06-26 13:02:57 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:03:00 --> Unable to connect to the database
ERROR - 2019-06-26 13:03:00 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:03:01 --> Unable to connect to the database
ERROR - 2019-06-26 13:03:01 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:03:05 --> Unable to connect to the database
ERROR - 2019-06-26 13:03:05 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:03:08 --> Unable to connect to the database
ERROR - 2019-06-26 13:03:08 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:03:10 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 13:03:11 --> Unable to connect to the database
ERROR - 2019-06-26 13:03:11 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:03:13 --> Unable to connect to the database
ERROR - 2019-06-26 13:03:13 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:03:18 --> Unable to connect to the database
ERROR - 2019-06-26 13:03:18 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:03:18 --> Unable to connect to the database
ERROR - 2019-06-26 13:03:18 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:03:20 --> Unable to connect to the database
ERROR - 2019-06-26 13:03:20 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:03:20 --> Unable to connect to the database
ERROR - 2019-06-26 13:03:21 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:03:24 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 13:03:27 --> Unable to connect to the database
ERROR - 2019-06-26 13:03:27 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:03:38 --> Unable to connect to the database
ERROR - 2019-06-26 13:03:38 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:03:39 --> Unable to connect to the database
ERROR - 2019-06-26 13:03:39 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:03:42 --> Unable to connect to the database
ERROR - 2019-06-26 13:03:42 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:03:42 --> Unable to connect to the database
ERROR - 2019-06-26 13:03:42 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:03:43 --> Unable to connect to the database
ERROR - 2019-06-26 13:03:43 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:03:44 --> Unable to connect to the database
ERROR - 2019-06-26 13:03:44 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:03:46 --> Unable to connect to the database
ERROR - 2019-06-26 13:03:46 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:03:46 --> Unable to connect to the database
ERROR - 2019-06-26 13:03:46 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:03:49 --> Unable to connect to the database
ERROR - 2019-06-26 13:03:49 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:03:54 --> Unable to connect to the database
ERROR - 2019-06-26 13:03:54 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:03:55 --> Unable to connect to the database
ERROR - 2019-06-26 13:03:55 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:03:58 --> Unable to connect to the database
ERROR - 2019-06-26 13:03:58 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:03:58 --> Unable to connect to the database
ERROR - 2019-06-26 13:03:58 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:04:00 --> Unable to connect to the database
ERROR - 2019-06-26 13:04:00 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:04:08 --> Unable to connect to the database
ERROR - 2019-06-26 13:04:08 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:04:12 --> Unable to connect to the database
ERROR - 2019-06-26 13:04:12 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:04:24 --> Unable to connect to the database
ERROR - 2019-06-26 13:04:24 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:04:25 --> Unable to connect to the database
ERROR - 2019-06-26 13:04:25 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:04:26 --> Unable to connect to the database
ERROR - 2019-06-26 13:04:26 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:04:30 --> Unable to connect to the database
ERROR - 2019-06-26 13:04:30 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:04:31 --> Unable to connect to the database
ERROR - 2019-06-26 13:04:31 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:04:34 --> Unable to connect to the database
ERROR - 2019-06-26 13:04:34 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:04:36 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 13:04:55 --> Unable to connect to the database
ERROR - 2019-06-26 13:04:55 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:04:55 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 13:04:57 --> Unable to connect to the database
ERROR - 2019-06-26 13:04:57 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:04:59 --> Unable to connect to the database
ERROR - 2019-06-26 13:04:59 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:05:01 --> Unable to connect to the database
ERROR - 2019-06-26 13:05:01 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:05:02 --> Unable to connect to the database
ERROR - 2019-06-26 13:05:02 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:05:03 --> Unable to connect to the database
ERROR - 2019-06-26 13:05:03 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:05:03 --> Unable to connect to the database
ERROR - 2019-06-26 13:05:03 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:05:04 --> Unable to connect to the database
ERROR - 2019-06-26 13:05:04 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:05:04 --> Unable to connect to the database
ERROR - 2019-06-26 13:05:04 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:05:06 --> Unable to connect to the database
ERROR - 2019-06-26 13:05:06 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:05:07 --> Unable to connect to the database
ERROR - 2019-06-26 13:05:07 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:05:08 --> Unable to connect to the database
ERROR - 2019-06-26 13:05:08 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:05:11 --> Unable to connect to the database
ERROR - 2019-06-26 13:05:11 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:05:12 --> Unable to connect to the database
ERROR - 2019-06-26 13:05:12 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:05:13 --> Unable to connect to the database
ERROR - 2019-06-26 13:05:13 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:05:19 --> Unable to connect to the database
ERROR - 2019-06-26 13:05:19 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:05:26 --> Unable to connect to the database
ERROR - 2019-06-26 13:05:26 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:05:29 --> Unable to connect to the database
ERROR - 2019-06-26 13:05:29 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:05:32 --> Unable to connect to the database
ERROR - 2019-06-26 13:05:32 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:05:34 --> Unable to connect to the database
ERROR - 2019-06-26 13:05:34 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:05:38 --> Unable to connect to the database
ERROR - 2019-06-26 13:05:38 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:05:43 --> Unable to connect to the database
ERROR - 2019-06-26 13:05:43 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:05:48 --> Unable to connect to the database
ERROR - 2019-06-26 13:05:48 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:05:50 --> Unable to connect to the database
ERROR - 2019-06-26 13:05:50 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:05:55 --> Unable to connect to the database
ERROR - 2019-06-26 13:05:55 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:06:02 --> Unable to connect to the database
ERROR - 2019-06-26 13:06:02 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:06:03 --> Unable to connect to the database
ERROR - 2019-06-26 13:06:03 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:06:04 --> Unable to connect to the database
ERROR - 2019-06-26 13:06:04 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:06:04 --> Unable to connect to the database
ERROR - 2019-06-26 13:06:04 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:06:07 --> Unable to connect to the database
ERROR - 2019-06-26 13:06:07 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:06:08 --> Unable to connect to the database
ERROR - 2019-06-26 13:06:08 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:06:12 --> Unable to connect to the database
ERROR - 2019-06-26 13:06:12 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:06:24 --> Unable to connect to the database
ERROR - 2019-06-26 13:06:24 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:06:27 --> Unable to connect to the database
ERROR - 2019-06-26 13:06:27 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:06:34 --> Unable to connect to the database
ERROR - 2019-06-26 13:06:34 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:06:38 --> Unable to connect to the database
ERROR - 2019-06-26 13:06:38 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:06:39 --> Unable to connect to the database
ERROR - 2019-06-26 13:06:39 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:06:41 --> Unable to connect to the database
ERROR - 2019-06-26 13:06:41 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:06:43 --> Unable to connect to the database
ERROR - 2019-06-26 13:06:43 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:06:51 --> Unable to connect to the database
ERROR - 2019-06-26 13:06:51 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:06:52 --> Unable to connect to the database
ERROR - 2019-06-26 13:06:52 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:06:55 --> Unable to connect to the database
ERROR - 2019-06-26 13:06:55 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:06:56 --> Unable to connect to the database
ERROR - 2019-06-26 13:06:56 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:06:58 --> Unable to connect to the database
ERROR - 2019-06-26 13:06:58 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:06:59 --> Unable to connect to the database
ERROR - 2019-06-26 13:06:59 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:07:05 --> Unable to connect to the database
ERROR - 2019-06-26 13:07:05 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:07:11 --> Unable to connect to the database
ERROR - 2019-06-26 13:07:11 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:07:12 --> Unable to connect to the database
ERROR - 2019-06-26 13:07:12 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:07:16 --> Unable to connect to the database
ERROR - 2019-06-26 13:07:16 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:07:23 --> Unable to connect to the database
ERROR - 2019-06-26 13:07:23 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:07:31 --> Unable to connect to the database
ERROR - 2019-06-26 13:07:31 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:07:34 --> Unable to connect to the database
ERROR - 2019-06-26 13:07:34 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:07:36 --> Unable to connect to the database
ERROR - 2019-06-26 13:07:36 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:07:37 --> Unable to connect to the database
ERROR - 2019-06-26 13:07:37 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:07:37 --> Unable to connect to the database
ERROR - 2019-06-26 13:07:37 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:07:43 --> Unable to connect to the database
ERROR - 2019-06-26 13:07:43 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:07:52 --> Unable to connect to the database
ERROR - 2019-06-26 13:07:52 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:08:00 --> Unable to connect to the database
ERROR - 2019-06-26 13:08:00 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:08:05 --> Unable to connect to the database
ERROR - 2019-06-26 13:08:05 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:08:09 --> Unable to connect to the database
ERROR - 2019-06-26 13:08:09 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:08:11 --> Unable to connect to the database
ERROR - 2019-06-26 13:08:11 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:08:18 --> Unable to connect to the database
ERROR - 2019-06-26 13:08:18 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:08:26 --> Unable to connect to the database
ERROR - 2019-06-26 13:08:26 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:08:28 --> Unable to connect to the database
ERROR - 2019-06-26 13:08:28 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:08:32 --> Unable to connect to the database
ERROR - 2019-06-26 13:08:32 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:08:32 --> Unable to connect to the database
ERROR - 2019-06-26 13:08:32 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:08:34 --> Unable to connect to the database
ERROR - 2019-06-26 13:08:34 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:08:36 --> Unable to connect to the database
ERROR - 2019-06-26 13:08:36 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:08:38 --> Unable to connect to the database
ERROR - 2019-06-26 13:08:38 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:08:38 --> Unable to connect to the database
ERROR - 2019-06-26 13:08:38 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:08:42 --> Unable to connect to the database
ERROR - 2019-06-26 13:08:42 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:08:44 --> Unable to connect to the database
ERROR - 2019-06-26 13:08:44 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:08:46 --> Unable to connect to the database
ERROR - 2019-06-26 13:08:46 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:08:50 --> Unable to connect to the database
ERROR - 2019-06-26 13:08:50 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:08:50 --> Unable to connect to the database
ERROR - 2019-06-26 13:08:50 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:08:51 --> Unable to connect to the database
ERROR - 2019-06-26 13:08:51 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:08:53 --> Unable to connect to the database
ERROR - 2019-06-26 13:08:53 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:08:55 --> Unable to connect to the database
ERROR - 2019-06-26 13:08:55 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:08:57 --> Unable to connect to the database
ERROR - 2019-06-26 13:08:57 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:08:59 --> Unable to connect to the database
ERROR - 2019-06-26 13:08:59 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:08:59 --> Unable to connect to the database
ERROR - 2019-06-26 13:08:59 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:09:01 --> Unable to connect to the database
ERROR - 2019-06-26 13:09:01 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:09:02 --> Unable to connect to the database
ERROR - 2019-06-26 13:09:02 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:09:03 --> Unable to connect to the database
ERROR - 2019-06-26 13:09:03 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:09:03 --> Unable to connect to the database
ERROR - 2019-06-26 13:09:03 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:09:03 --> Unable to connect to the database
ERROR - 2019-06-26 13:09:03 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:09:05 --> Unable to connect to the database
ERROR - 2019-06-26 13:09:05 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:09:07 --> Unable to connect to the database
ERROR - 2019-06-26 13:09:07 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:09:14 --> Unable to connect to the database
ERROR - 2019-06-26 13:09:14 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:09:19 --> Unable to connect to the database
ERROR - 2019-06-26 13:09:19 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:09:22 --> Unable to connect to the database
ERROR - 2019-06-26 13:09:22 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:09:24 --> Unable to connect to the database
ERROR - 2019-06-26 13:09:24 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:09:27 --> Unable to connect to the database
ERROR - 2019-06-26 13:09:27 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:09:28 --> Unable to connect to the database
ERROR - 2019-06-26 13:09:28 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:09:32 --> Unable to connect to the database
ERROR - 2019-06-26 13:09:32 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:09:36 --> Unable to connect to the database
ERROR - 2019-06-26 13:09:36 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:09:49 --> Unable to connect to the database
ERROR - 2019-06-26 13:09:49 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:09:49 --> Unable to connect to the database
ERROR - 2019-06-26 13:09:49 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:09:52 --> Unable to connect to the database
ERROR - 2019-06-26 13:09:52 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:09:54 --> Unable to connect to the database
ERROR - 2019-06-26 13:09:54 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:09:54 --> Unable to connect to the database
ERROR - 2019-06-26 13:09:54 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:09:57 --> Unable to connect to the database
ERROR - 2019-06-26 13:09:57 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:09:58 --> Unable to connect to the database
ERROR - 2019-06-26 13:09:58 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:09:59 --> Unable to connect to the database
ERROR - 2019-06-26 13:09:59 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:10:00 --> Unable to connect to the database
ERROR - 2019-06-26 13:10:00 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:10:05 --> Unable to connect to the database
ERROR - 2019-06-26 13:10:05 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:10:15 --> Unable to connect to the database
ERROR - 2019-06-26 13:10:15 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:10:16 --> Unable to connect to the database
ERROR - 2019-06-26 13:10:16 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:10:23 --> Unable to connect to the database
ERROR - 2019-06-26 13:10:23 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:10:26 --> Unable to connect to the database
ERROR - 2019-06-26 13:10:26 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:10:31 --> Unable to connect to the database
ERROR - 2019-06-26 13:10:31 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:10:34 --> Unable to connect to the database
ERROR - 2019-06-26 13:10:34 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:10:36 --> Unable to connect to the database
ERROR - 2019-06-26 13:10:36 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:10:37 --> Unable to connect to the database
ERROR - 2019-06-26 13:10:37 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:10:38 --> Unable to connect to the database
ERROR - 2019-06-26 13:10:38 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:10:39 --> Unable to connect to the database
ERROR - 2019-06-26 13:10:39 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:10:41 --> Unable to connect to the database
ERROR - 2019-06-26 13:10:41 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:10:47 --> Unable to connect to the database
ERROR - 2019-06-26 13:10:47 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:10:50 --> Unable to connect to the database
ERROR - 2019-06-26 13:10:50 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:10:53 --> Unable to connect to the database
ERROR - 2019-06-26 13:10:53 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:10:55 --> Unable to connect to the database
ERROR - 2019-06-26 13:10:55 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:10:55 --> Unable to connect to the database
ERROR - 2019-06-26 13:10:55 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:10:56 --> Unable to connect to the database
ERROR - 2019-06-26 13:10:56 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:10:57 --> Unable to connect to the database
ERROR - 2019-06-26 13:10:57 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:10:59 --> Unable to connect to the database
ERROR - 2019-06-26 13:10:59 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:11:01 --> Unable to connect to the database
ERROR - 2019-06-26 13:11:01 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:11:01 --> Unable to connect to the database
ERROR - 2019-06-26 13:11:01 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:11:04 --> Unable to connect to the database
ERROR - 2019-06-26 13:11:04 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:11:07 --> Unable to connect to the database
ERROR - 2019-06-26 13:11:07 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:11:09 --> Unable to connect to the database
ERROR - 2019-06-26 13:11:09 --> Unable to connect to the database
ERROR - 2019-06-26 13:11:09 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:11:09 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:11:11 --> Unable to connect to the database
ERROR - 2019-06-26 13:11:11 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:11:11 --> Unable to connect to the database
ERROR - 2019-06-26 13:11:11 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:11:16 --> Unable to connect to the database
ERROR - 2019-06-26 13:11:16 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:11:17 --> Unable to connect to the database
ERROR - 2019-06-26 13:11:17 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:11:18 --> Unable to connect to the database
ERROR - 2019-06-26 13:11:18 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:11:24 --> Unable to connect to the database
ERROR - 2019-06-26 13:11:24 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:11:25 --> Unable to connect to the database
ERROR - 2019-06-26 13:11:25 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:11:27 --> Unable to connect to the database
ERROR - 2019-06-26 13:11:27 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:11:27 --> Unable to connect to the database
ERROR - 2019-06-26 13:11:27 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:11:31 --> Unable to connect to the database
ERROR - 2019-06-26 13:11:31 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:11:32 --> Unable to connect to the database
ERROR - 2019-06-26 13:11:32 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:11:34 --> Unable to connect to the database
ERROR - 2019-06-26 13:11:34 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:11:34 --> Unable to connect to the database
ERROR - 2019-06-26 13:11:34 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:11:39 --> Unable to connect to the database
ERROR - 2019-06-26 13:11:39 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:11:42 --> Unable to connect to the database
ERROR - 2019-06-26 13:11:42 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:11:48 --> Unable to connect to the database
ERROR - 2019-06-26 13:11:48 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:11:53 --> Unable to connect to the database
ERROR - 2019-06-26 13:11:53 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:11:55 --> Unable to connect to the database
ERROR - 2019-06-26 13:11:55 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:12:00 --> Unable to connect to the database
ERROR - 2019-06-26 13:12:00 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:12:08 --> Unable to connect to the database
ERROR - 2019-06-26 13:12:08 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:12:15 --> Unable to connect to the database
ERROR - 2019-06-26 13:12:15 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:12:22 --> Unable to connect to the database
ERROR - 2019-06-26 13:12:22 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:12:23 --> Unable to connect to the database
ERROR - 2019-06-26 13:12:23 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:12:36 --> Unable to connect to the database
ERROR - 2019-06-26 13:12:36 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:12:39 --> Unable to connect to the database
ERROR - 2019-06-26 13:12:39 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:12:39 --> Unable to connect to the database
ERROR - 2019-06-26 13:12:39 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:12:40 --> Unable to connect to the database
ERROR - 2019-06-26 13:12:40 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:12:41 --> Unable to connect to the database
ERROR - 2019-06-26 13:12:41 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:12:47 --> Unable to connect to the database
ERROR - 2019-06-26 13:12:47 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:12:51 --> Unable to connect to the database
ERROR - 2019-06-26 13:12:51 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:12:54 --> Unable to connect to the database
ERROR - 2019-06-26 13:12:54 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:13:01 --> Unable to connect to the database
ERROR - 2019-06-26 13:13:01 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:13:04 --> Unable to connect to the database
ERROR - 2019-06-26 13:13:04 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:13:07 --> Unable to connect to the database
ERROR - 2019-06-26 13:13:07 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:13:14 --> Unable to connect to the database
ERROR - 2019-06-26 13:13:14 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:13:21 --> Unable to connect to the database
ERROR - 2019-06-26 13:13:21 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:13:26 --> Unable to connect to the database
ERROR - 2019-06-26 13:13:26 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:13:31 --> Unable to connect to the database
ERROR - 2019-06-26 13:13:31 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:13:33 --> Unable to connect to the database
ERROR - 2019-06-26 13:13:33 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:13:34 --> Unable to connect to the database
ERROR - 2019-06-26 13:13:34 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:13:34 --> Unable to connect to the database
ERROR - 2019-06-26 13:13:34 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:14:04 --> Unable to connect to the database
ERROR - 2019-06-26 13:14:04 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:14:09 --> Unable to connect to the database
ERROR - 2019-06-26 13:14:09 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:14:12 --> Unable to connect to the database
ERROR - 2019-06-26 13:14:12 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:14:15 --> Unable to connect to the database
ERROR - 2019-06-26 13:14:16 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:14:16 --> Unable to connect to the database
ERROR - 2019-06-26 13:14:16 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:14:24 --> Unable to connect to the database
ERROR - 2019-06-26 13:14:24 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:14:29 --> Unable to connect to the database
ERROR - 2019-06-26 13:14:29 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:14:31 --> Unable to connect to the database
ERROR - 2019-06-26 13:14:31 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:14:49 --> Unable to connect to the database
ERROR - 2019-06-26 13:14:49 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:14:49 --> Unable to connect to the database
ERROR - 2019-06-26 13:14:49 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:14:51 --> Unable to connect to the database
ERROR - 2019-06-26 13:14:51 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:14:53 --> Unable to connect to the database
ERROR - 2019-06-26 13:14:53 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:15:09 --> Unable to connect to the database
ERROR - 2019-06-26 13:15:09 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:15:24 --> Unable to connect to the database
ERROR - 2019-06-26 13:15:24 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:15:37 --> Unable to connect to the database
ERROR - 2019-06-26 13:15:37 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:15:42 --> Unable to connect to the database
ERROR - 2019-06-26 13:15:42 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:15:46 --> Unable to connect to the database
ERROR - 2019-06-26 13:15:46 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:15:48 --> Unable to connect to the database
ERROR - 2019-06-26 13:15:48 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:15:49 --> Unable to connect to the database
ERROR - 2019-06-26 13:15:49 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:15:54 --> Unable to connect to the database
ERROR - 2019-06-26 13:15:54 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:15:54 --> Unable to connect to the database
ERROR - 2019-06-26 13:15:54 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:15:57 --> Unable to connect to the database
ERROR - 2019-06-26 13:15:57 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:15:58 --> Unable to connect to the database
ERROR - 2019-06-26 13:15:58 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:15:58 --> Unable to connect to the database
ERROR - 2019-06-26 13:15:58 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:16:03 --> Unable to connect to the database
ERROR - 2019-06-26 13:16:03 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:16:04 --> Unable to connect to the database
ERROR - 2019-06-26 13:16:04 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:16:05 --> Unable to connect to the database
ERROR - 2019-06-26 13:16:05 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:16:05 --> Unable to connect to the database
ERROR - 2019-06-26 13:16:05 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:16:07 --> Unable to connect to the database
ERROR - 2019-06-26 13:16:07 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:16:13 --> Unable to connect to the database
ERROR - 2019-06-26 13:16:13 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:16:13 --> Unable to connect to the database
ERROR - 2019-06-26 13:16:13 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:16:14 --> Unable to connect to the database
ERROR - 2019-06-26 13:16:14 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:16:15 --> Unable to connect to the database
ERROR - 2019-06-26 13:16:15 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:16:16 --> Unable to connect to the database
ERROR - 2019-06-26 13:16:16 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:16:16 --> Unable to connect to the database
ERROR - 2019-06-26 13:16:16 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:16:25 --> Unable to connect to the database
ERROR - 2019-06-26 13:16:25 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:16:26 --> Unable to connect to the database
ERROR - 2019-06-26 13:16:26 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:16:29 --> Unable to connect to the database
ERROR - 2019-06-26 13:16:29 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:16:30 --> Unable to connect to the database
ERROR - 2019-06-26 13:16:30 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:16:35 --> Unable to connect to the database
ERROR - 2019-06-26 13:16:35 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:16:38 --> Unable to connect to the database
ERROR - 2019-06-26 13:16:38 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:16:47 --> Unable to connect to the database
ERROR - 2019-06-26 13:16:47 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:16:50 --> Unable to connect to the database
ERROR - 2019-06-26 13:16:50 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:16:54 --> Unable to connect to the database
ERROR - 2019-06-26 13:16:54 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:16:56 --> Unable to connect to the database
ERROR - 2019-06-26 13:16:56 --> Severity: Error --> session_start(): Failed to initialize storage module: user (path: ci_sessions) /home/compatl8/public_html/tools/system/libraries/Session/Session.php 143
ERROR - 2019-06-26 13:21:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:21:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 13:26:27 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-26 13:27:35 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-26 13:28:34 --> Query error: Column 'fy' cannot be null - Invalid query: INSERT INTO `planheader` (`icpNo`, `fy`) VALUES ('KE262', NULL)
ERROR - 2019-06-26 13:28:34 --> Query error: Column 'planHeaderID' cannot be null - Invalid query: INSERT INTO `plansschedule` (`planHeaderID`, `AccNo`, `plan_item_tag_id`, `details`, `qty`, `unitCost`, `often`, `totalCost`, `notes`, `month_1_amount`, `month_2_amount`, `month_3_amount`, `month_4_amount`, `month_5_amount`, `month_6_amount`, `month_7_amount`, `month_8_amount`, `month_9_amount`, `month_10_amount`, `month_11_amount`, `month_12_amount`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2019-06-26 13:33:38 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-26 13:40:43 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 81
ERROR - 2019-06-26 13:40:43 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 82
ERROR - 2019-06-26 13:54:47 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-26 13:59:02 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-26 14:10:14 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-26 14:11:28 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-26 14:11:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:11:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:11:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:11:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:11:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:11:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:11:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:11:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:11:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:11:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:11:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:11:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:11:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:11:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:11:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:11:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:11:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:11:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:11:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:11:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:11:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:11:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:11:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:11:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:11:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:11:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:11:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:11:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:11:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:11:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:11:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:11:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:11:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:11:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:11:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:11:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:11:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:11:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:11:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:11:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:11:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:11:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:11:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:11:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:11:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:11:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:11:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:11:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:11:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:11:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:11:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:11:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:11:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:11:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:11:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:11:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:11:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:11:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:11:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:16:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-06-26 14:19:23 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-06-26 14:21:31 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-26 14:44:59 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-06-26 14:45:38 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-26 14:48:52 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-06-26 14:53:15 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-26 14:53:47 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-06-26 14:54:02 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-26 14:56:07 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-26 16:23:40 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-26 16:50:49 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 16:50:51 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 16:51:13 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-26 17:24:05 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-26 17:25:53 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-26 17:33:38 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
