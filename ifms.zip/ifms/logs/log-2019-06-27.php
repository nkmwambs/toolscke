<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-06-27 03:01:06 --> 404 Page Not Found: Facilitator/assets
ERROR - 2019-06-27 03:57:50 --> 404 Page Not Found: Civa/assets
ERROR - 2019-06-27 05:50:45 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-06-27 05:50:45 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-06-27 05:50:46 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-06-27 05:50:46 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-06-27 05:50:46 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-06-27 06:27:17 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-27 06:27:22 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-27 06:27:26 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-27 06:27:27 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-27 06:27:30 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-27 06:27:30 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-27 06:27:50 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-27 06:27:53 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-27 06:27:54 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-27 06:27:54 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-27 06:27:56 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-27 06:28:00 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-27 06:28:01 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-27 06:28:01 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-06-27 06:32:23 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-27 06:32:24 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-27 06:34:48 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-27 06:37:32 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-27 06:39:35 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-06-27 06:45:36 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-06-27 06:47:47 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-27 06:52:04 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-27 07:02:44 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-27 07:03:23 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-27 07:24:14 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-27 07:28:19 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-06-27 07:30:20 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-27 07:46:33 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-06-27 07:51:18 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-06-27 07:54:30 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
