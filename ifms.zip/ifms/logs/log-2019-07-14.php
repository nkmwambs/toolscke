<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-07-14 04:45:23 --> 404 Page Not Found: Civa/assets
ERROR - 2019-07-14 10:12:28 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
