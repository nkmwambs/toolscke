<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-07-21 07:43:22 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-07-21 07:43:38 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
