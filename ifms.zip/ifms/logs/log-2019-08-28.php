<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-08-28 04:39:24 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-08-28 04:39:27 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-08-28 04:47:39 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-08-28 04:47:40 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-08-28 04:47:57 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-08-28 04:48:14 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-08-28 04:48:20 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-08-28 04:48:27 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-08-28 06:01:40 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-08-28 06:06:38 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 81
ERROR - 2019-08-28 06:06:38 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 82
ERROR - 2019-08-28 06:40:27 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-08-28 06:40:48 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-08-28 06:41:11 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-08-28 06:41:18 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-08-28 06:57:54 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-08-28 06:57:58 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-08-28 06:58:00 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-08-28 07:01:33 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-08-28 07:02:23 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-08-28 07:13:11 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-08-28 07:13:15 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-08-28 07:13:25 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-08-28 07:14:12 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-08-28 07:27:34 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:36:55 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:46 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:46 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:46 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-08-28 07:38:53 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-08-28 07:39:58 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-08-28 07:39:58 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-08-28 07:50:50 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-08-28 07:50:51 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-08-28 07:56:30 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-08-28 07:57:14 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-08-28 07:57:49 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/health/dashboard.php 12
ERROR - 2019-08-28 07:57:57 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/health/dashboard.php 252
ERROR - 2019-08-28 07:57:58 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/health/dashboard.php 252
ERROR - 2019-08-28 07:58:02 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/health/dashboard.php 252
ERROR - 2019-08-28 07:58:02 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/health/dashboard.php 252
ERROR - 2019-08-28 07:58:09 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/health/dashboard.php 252
ERROR - 2019-08-28 07:58:17 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/health/dashboard.php 252
ERROR - 2019-08-28 07:58:17 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/health/dashboard.php 252
ERROR - 2019-08-28 07:58:34 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/health/dashboard.php 252
ERROR - 2019-08-28 08:01:54 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-08-28 08:01:54 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-08-28 08:08:25 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 81
ERROR - 2019-08-28 08:08:25 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 82
ERROR - 2019-08-28 08:09:39 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 81
ERROR - 2019-08-28 08:09:39 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 82
ERROR - 2019-08-28 08:09:53 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-08-28 08:09:53 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-08-28 08:09:54 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 81
ERROR - 2019-08-28 08:09:54 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 82
ERROR - 2019-08-28 08:22:34 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-08-28 08:22:34 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-08-28 08:28:15 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-08-28 08:28:15 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-08-28 08:28:17 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-08-28 08:34:25 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-08-28 08:44:56 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-08-28 08:47:43 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-08-28 08:47:45 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-08-28 08:47:50 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-08-28 08:53:38 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-08-28 08:53:38 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-08-28 08:54:49 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-08-28 08:57:47 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 81
ERROR - 2019-08-28 08:57:47 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 82
ERROR - 2019-08-28 09:00:31 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-08-28 09:00:54 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 81
ERROR - 2019-08-28 09:00:54 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 82
ERROR - 2019-08-28 09:49:53 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:49:53 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:49:53 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:49:53 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:49:53 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:49:53 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:49:53 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:49:53 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:49:53 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:49:53 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:49:53 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:49:53 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:49:53 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:49:53 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:49:53 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:49:53 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:49:53 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:49:53 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:49:53 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:49:53 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:49:53 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:49:53 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:49:53 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:49:53 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:49:53 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:49:53 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:49:53 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:49:53 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:49:53 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:49:53 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:49:53 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:49:53 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:49:53 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:49:53 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:49:53 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:49:53 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:49:53 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:49:53 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:49:53 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:49:53 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:49:53 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:49:53 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:49:53 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:49:53 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:49:53 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:49:53 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:49:53 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:49:53 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:49:53 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:49:53 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:49:53 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:49:53 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:49:53 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:49:53 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:49:53 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:49:53 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:49:53 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:49:53 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:49:53 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:49:53 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:49:53 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:49:53 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:49:53 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:49:53 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:49:53 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:49:53 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:49:53 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:49:53 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:49:53 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:49:53 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:49:53 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:49:53 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:49:53 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:49:53 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:49:53 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:49:53 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:49:53 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:49:53 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:49:53 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:55:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 09:59:07 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-08-28 09:59:12 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-08-28 09:59:13 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-08-28 09:59:14 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-08-28 10:02:49 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-08-28 10:03:03 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-08-28 10:03:03 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-08-28 10:03:04 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-08-28 10:03:05 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-08-28 10:03:24 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-08-28 10:08:40 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-08-28 10:11:50 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-08-28 10:31:42 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-08-28 10:41:28 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-08-28 10:49:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:49:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:49:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:49:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:49:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:49:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:49:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:49:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:49:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:49:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:49:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:49:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:49:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:49:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:49:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:49:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:49:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:49:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:49:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:49:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:49:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:49:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:49:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:49:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:49:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:49:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:49:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:49:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:49:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:49:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:49:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:49:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:49:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:49:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:49:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:49:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:49:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:49:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:49:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:49:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:49:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:49:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:49:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:49:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:49:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:49:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:49:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:49:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:49:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:49:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:49:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:49:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:49:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:49:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:49:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:49:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:49:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:49:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:49:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:49:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:49:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:49:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:49:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:49:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:49:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:49:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:49:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:49:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:49:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:49:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:49:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:49:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:49:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:49:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:49:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:49:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:49:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:49:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:49:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:25 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:50:26 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:52:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:52:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:52:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:52:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:52:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:52:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:52:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:52:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:52:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:52:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:52:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:52:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:52:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:52:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:52:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:52:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:52:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:52:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:52:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:52:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:52:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:52:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:52:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:52:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:52:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:52:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:52:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:52:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:52:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:52:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:52:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:52:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:52:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:52:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:52:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:52:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:52:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:52:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:52:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:52:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:52:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:52:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:52:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:52:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:52:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:52:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:52:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:52:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:52:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:52:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:52:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:52:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:52:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:52:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:52:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:52:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:52:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:52:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:52:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:52:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:52:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:52:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:52:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:52:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:52:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:52:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:52:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:52:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:52:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:52:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:52:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:52:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:52:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:52:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:52:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:52:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:52:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:52:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:52:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 10:59:20 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-08-28 11:05:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:05:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:05:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:05:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:05:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:05:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:05:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:05:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:05:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:05:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:05:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:05:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:05:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:05:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:05:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:05:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:05:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:05:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:05:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:05:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:05:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:05:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:05:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:05:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:05:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:05:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:05:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:05:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:05:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:05:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:05:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:05:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:05:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:05:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:05:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:05:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:05:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:05:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:05:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:05:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:05:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:05:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:05:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:05:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:05:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:05:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:05:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:05:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:05:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:05:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:05:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:05:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:05:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:05:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:05:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:05:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:05:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:05:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:05:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:05:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:05:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:05:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:05:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:05:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:05:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:05:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:05:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:05:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:05:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:05:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:05:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:05:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:05:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:05:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:05:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:05:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:05:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:05:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:05:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:31 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:31 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:31 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:31 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:31 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:31 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:31 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:31 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:31 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:31 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:31 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:31 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:31 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:31 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:31 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:31 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:31 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:31 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:31 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:31 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:31 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:31 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:31 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:31 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:31 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:31 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:31 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:31 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:31 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:31 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:31 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:31 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:31 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:31 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:31 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:31 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:31 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:31 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:31 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:31 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:31 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:31 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:31 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:31 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:31 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:31 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:31 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:31 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:31 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:31 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:31 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:31 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:31 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:31 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:31 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:31 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:31 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:31 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:31 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:31 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:31 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:31 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:31 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:31 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:31 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:31 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:31 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:31 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:31 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:31 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:31 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:31 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:31 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:31 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:31 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:31 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:31 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:31 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:31 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:07:35 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 11:21:05 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-08-28 11:22:37 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-08-28 11:24:42 --> 404 Page Not Found: Facilitator/assets
ERROR - 2019-08-28 11:26:09 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-08-28 11:27:18 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-08-28 11:28:19 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-08-28 11:28:19 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-08-28 11:28:20 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-08-28 11:29:48 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-08-28 11:29:48 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-08-28 11:29:56 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-08-28 11:54:14 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-08-28 11:54:15 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-08-28 11:56:23 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-08-28 11:56:56 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-08-28 12:15:00 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:00 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:00 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:00 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:00 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:00 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:00 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:00 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:00 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:00 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:00 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:00 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:00 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:00 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:00 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:00 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:00 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:00 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:00 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:00 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:00 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:00 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:00 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:00 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:00 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:00 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:00 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:00 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:00 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:00 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:00 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:00 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:00 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:00 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:00 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:00 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:00 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:00 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:00 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:00 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:00 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:00 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:00 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:00 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:00 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:00 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:00 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:00 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:00 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:00 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:00 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:00 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:00 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:00 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:00 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:00 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:00 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:00 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:00 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:00 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:00 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:00 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:00 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:00 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:00 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:00 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:00 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:00 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:00 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:00 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:00 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:00 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:00 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:00 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:00 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:00 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:00 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:00 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:00 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:38 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:38 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:38 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:38 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:38 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:38 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:38 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:38 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:38 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:38 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:38 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:38 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:38 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:38 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:38 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:38 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:38 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:38 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:38 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:38 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:38 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:38 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:38 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:38 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:38 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:38 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:38 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:38 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:38 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:38 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:38 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:38 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:38 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:38 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:38 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:38 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:38 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:38 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:38 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:38 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:38 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:38 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:38 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:38 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:38 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:38 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:38 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:38 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:38 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:38 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:38 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:38 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:38 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:38 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:38 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:38 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:38 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:38 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:38 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:38 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:38 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:38 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:38 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:38 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:38 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:38 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:38 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:38 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:38 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:38 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:38 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:38 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:38 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:38 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:38 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:38 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:38 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:38 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:15:38 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-08-28 12:23:25 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-08-28 12:25:18 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-08-28 12:25:19 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-08-28 12:25:35 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-08-28 12:57:23 --> 404 Page Not Found: Facilitator/assets
ERROR - 2019-08-28 12:57:44 --> 404 Page Not Found: Facilitator/assets
ERROR - 2019-08-28 13:14:12 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-08-28 13:20:23 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-08-28 13:20:24 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-08-28 13:25:50 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-08-28 13:31:24 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-08-28 13:34:32 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-08-28 13:42:28 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-08-28 13:46:23 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-08-28 13:50:07 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-08-28 14:05:47 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-08-28 14:56:37 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-08-28 14:56:39 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-08-28 15:24:46 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 81
ERROR - 2019-08-28 15:24:46 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 82
ERROR - 2019-08-28 18:11:18 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-08-28 18:30:39 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-08-28 21:32:54 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
