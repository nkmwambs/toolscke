<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-09-24 06:17:26 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-24 07:13:41 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2019-09-24 07:15:18 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-24 07:15:20 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-24 07:15:21 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-24 07:15:23 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-24 07:15:25 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-24 07:52:25 --> 404 Page Not Found: Facilitator/assets
ERROR - 2019-09-24 08:30:42 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-09-24 08:31:41 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-09-24 08:32:30 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-24 08:32:36 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-09-24 08:45:56 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-24 08:45:59 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-24 08:46:01 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:17 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:51:18 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:51:44 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-24 08:51:45 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-24 08:51:47 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-24 08:51:49 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-24 08:53:01 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-24 08:54:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-24 08:58:08 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-24 09:00:12 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-24 09:03:47 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-24 09:13:22 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-24 09:19:43 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-24 09:20:12 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-09-24 09:25:29 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-24 09:29:29 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-24 09:29:30 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-24 09:33:38 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-09-24 09:34:08 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-09-24 09:35:01 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-09-24 09:43:02 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-24 09:43:06 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-24 09:46:15 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-24 09:46:58 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-09-24 09:56:39 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-24 10:03:50 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-24 10:05:59 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 85
ERROR - 2019-09-24 10:05:59 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 568
ERROR - 2019-09-24 10:05:59 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 568
ERROR - 2019-09-24 10:05:59 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 573
ERROR - 2019-09-24 10:05:59 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 573
ERROR - 2019-09-24 10:05:59 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 30
ERROR - 2019-09-24 10:05:59 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 40
ERROR - 2019-09-24 10:05:59 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 50
ERROR - 2019-09-24 10:05:59 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 72
ERROR - 2019-09-24 10:05:59 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 78
ERROR - 2019-09-24 10:05:59 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 84
ERROR - 2019-09-24 10:05:59 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 91
ERROR - 2019-09-24 10:05:59 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 97
ERROR - 2019-09-24 10:05:59 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 103
ERROR - 2019-09-24 10:05:59 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 110
ERROR - 2019-09-24 10:05:59 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 117
ERROR - 2019-09-24 10:05:59 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 124
ERROR - 2019-09-24 10:05:59 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 132
ERROR - 2019-09-24 10:05:59 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 140
ERROR - 2019-09-24 10:05:59 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 148
ERROR - 2019-09-24 10:05:59 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 157
ERROR - 2019-09-24 10:05:59 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 159
ERROR - 2019-09-24 10:05:59 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 186
ERROR - 2019-09-24 10:05:59 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 186
ERROR - 2019-09-24 10:05:59 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 212
ERROR - 2019-09-24 10:05:59 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 214
ERROR - 2019-09-24 10:05:59 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 218
ERROR - 2019-09-24 10:05:59 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 219
ERROR - 2019-09-24 10:05:59 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 239
ERROR - 2019-09-24 10:05:59 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 245
ERROR - 2019-09-24 10:06:00 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 690
ERROR - 2019-09-24 10:06:19 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 81
ERROR - 2019-09-24 10:06:19 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 82
ERROR - 2019-09-24 10:06:45 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 85
ERROR - 2019-09-24 10:06:46 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 568
ERROR - 2019-09-24 10:06:46 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 568
ERROR - 2019-09-24 10:06:46 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 573
ERROR - 2019-09-24 10:06:46 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 573
ERROR - 2019-09-24 10:06:46 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 30
ERROR - 2019-09-24 10:06:46 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 40
ERROR - 2019-09-24 10:06:46 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 50
ERROR - 2019-09-24 10:06:46 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 72
ERROR - 2019-09-24 10:06:46 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 78
ERROR - 2019-09-24 10:06:46 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 84
ERROR - 2019-09-24 10:06:46 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 91
ERROR - 2019-09-24 10:06:46 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 97
ERROR - 2019-09-24 10:06:46 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 103
ERROR - 2019-09-24 10:06:46 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 110
ERROR - 2019-09-24 10:06:46 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 117
ERROR - 2019-09-24 10:06:46 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 124
ERROR - 2019-09-24 10:06:46 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 132
ERROR - 2019-09-24 10:06:46 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 140
ERROR - 2019-09-24 10:06:46 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 148
ERROR - 2019-09-24 10:06:46 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 157
ERROR - 2019-09-24 10:06:46 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 159
ERROR - 2019-09-24 10:06:46 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 186
ERROR - 2019-09-24 10:06:46 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 186
ERROR - 2019-09-24 10:06:46 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 212
ERROR - 2019-09-24 10:06:46 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 214
ERROR - 2019-09-24 10:06:46 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 218
ERROR - 2019-09-24 10:06:46 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 219
ERROR - 2019-09-24 10:06:46 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 239
ERROR - 2019-09-24 10:06:46 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 245
ERROR - 2019-09-24 10:06:46 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 690
ERROR - 2019-09-24 10:06:53 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 81
ERROR - 2019-09-24 10:06:53 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 82
ERROR - 2019-09-24 10:07:27 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-24 10:09:54 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 85
ERROR - 2019-09-24 10:09:54 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 568
ERROR - 2019-09-24 10:09:54 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 568
ERROR - 2019-09-24 10:09:54 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 573
ERROR - 2019-09-24 10:09:54 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 573
ERROR - 2019-09-24 10:09:55 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 30
ERROR - 2019-09-24 10:09:55 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 40
ERROR - 2019-09-24 10:09:55 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 50
ERROR - 2019-09-24 10:09:55 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 72
ERROR - 2019-09-24 10:09:55 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 78
ERROR - 2019-09-24 10:09:55 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 84
ERROR - 2019-09-24 10:09:55 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 91
ERROR - 2019-09-24 10:09:55 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 97
ERROR - 2019-09-24 10:09:55 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 103
ERROR - 2019-09-24 10:09:55 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 110
ERROR - 2019-09-24 10:09:55 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 117
ERROR - 2019-09-24 10:09:55 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 124
ERROR - 2019-09-24 10:09:55 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 132
ERROR - 2019-09-24 10:09:55 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 140
ERROR - 2019-09-24 10:09:55 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 148
ERROR - 2019-09-24 10:09:55 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 157
ERROR - 2019-09-24 10:09:55 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 159
ERROR - 2019-09-24 10:09:55 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 186
ERROR - 2019-09-24 10:09:55 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 186
ERROR - 2019-09-24 10:09:55 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 212
ERROR - 2019-09-24 10:09:55 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 214
ERROR - 2019-09-24 10:09:55 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 218
ERROR - 2019-09-24 10:09:55 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 219
ERROR - 2019-09-24 10:09:55 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 239
ERROR - 2019-09-24 10:09:55 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 245
ERROR - 2019-09-24 10:09:55 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/views/backend/partner/cash_journal.php 690
ERROR - 2019-09-24 10:17:01 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-24 11:05:38 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-24 11:05:44 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-24 11:05:49 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-24 11:05:54 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-24 11:05:58 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-24 11:06:07 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-24 11:06:14 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-24 11:06:22 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-24 11:06:51 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-24 11:06:56 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-24 11:08:24 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-24 11:18:32 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-24 11:32:25 --> 404 Page Not Found: Facilitator/assets
ERROR - 2019-09-24 11:36:17 --> 404 Page Not Found: Facilitator/assets
ERROR - 2019-09-24 11:36:51 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-24 11:40:30 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-24 11:41:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 11:41:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 11:41:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 11:41:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 11:41:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 11:41:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 11:41:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 11:41:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 11:41:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 11:41:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 11:41:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 11:41:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 11:41:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 11:41:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 11:41:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 11:41:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 11:41:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 11:41:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 11:41:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 11:41:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 11:41:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 11:41:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 11:41:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 11:41:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 11:41:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 11:41:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 11:41:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 11:41:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 11:41:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 11:41:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 11:41:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 11:41:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 11:41:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 11:41:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 11:41:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 11:41:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 11:41:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 11:41:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 11:41:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 11:41:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 11:41:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 11:41:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 11:41:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 11:41:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 11:41:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 11:41:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 11:41:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 11:41:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 11:41:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 11:41:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 11:41:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 11:41:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 11:41:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 11:41:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 11:41:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 11:41:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 11:41:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 11:41:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 11:41:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 11:41:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 11:41:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 11:41:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 11:41:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 11:41:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 11:41:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 11:41:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 11:41:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 11:41:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 11:41:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 11:41:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 11:41:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 11:41:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 11:41:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 11:43:05 --> 404 Page Not Found: Facilitator/assets
ERROR - 2019-09-24 11:59:08 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-24 12:03:11 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-24 12:16:12 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-24 12:24:17 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-24 12:24:18 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-24 12:24:20 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-24 12:24:21 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-24 12:24:22 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-24 12:24:24 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-24 12:24:24 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-24 12:33:51 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-24 12:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:36:37 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-24 12:40:14 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-24 12:45:51 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-24 12:47:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:47:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:47:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:47:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:47:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:47:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:47:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:47:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:47:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:47:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:47:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:47:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:47:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:47:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:47:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:47:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:47:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:47:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:47:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:47:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:47:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:47:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:47:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:47:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:47:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:47:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:47:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:47:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:47:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:47:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:47:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:47:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:47:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:47:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:47:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:47:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:47:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:47:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:47:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:47:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:47:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:47:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:47:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:47:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:47:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:47:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:47:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:47:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:47:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:47:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:47:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:47:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:47:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:47:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:47:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:47:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:47:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:47:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:47:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:47:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:47:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:47:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:47:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:47:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:47:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:47:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:47:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:47:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:47:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:47:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:47:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:47:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:47:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:48:02 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-24 12:50:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:18 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:24 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-24 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 12:50:24 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 13:03:07 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-24 13:03:07 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-24 13:03:48 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-24 13:25:23 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-24 13:28:17 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-24 13:28:17 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-24 13:28:18 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-24 13:28:19 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-24 13:28:21 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-24 13:37:57 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-09-24 14:07:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:46 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:48 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:48 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:48 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:48 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:48 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:48 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:48 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:48 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:48 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:48 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:48 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:48 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:48 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:48 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:48 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:48 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:48 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:48 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:48 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:48 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:48 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:48 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:48 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:48 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:48 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:48 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:48 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:48 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:48 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:48 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:48 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:48 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:48 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:48 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:48 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:48 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:48 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:48 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:48 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:48 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:48 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:48 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:48 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:48 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:48 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:48 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:48 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:48 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:48 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:48 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:48 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:48 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:48 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:48 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:48 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:48 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:48 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:48 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:48 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:48 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:48 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:48 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:48 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:48 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:48 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:48 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:48 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:48 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:48 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:48 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:48 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:48 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:07:48 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:04 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:06 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:20 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:13:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:29 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:17:30 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:19:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:19:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:19:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:19:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:19:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:19:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:19:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:19:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:19:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:19:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:19:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:19:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:19:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:19:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:19:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:19:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:19:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:19:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:19:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:19:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:19:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:19:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:19:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:19:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:19:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:19:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:19:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:19:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:19:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:19:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:19:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:19:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:19:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:19:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:19:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:19:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:19:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:19:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:19:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:19:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:19:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:19:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:19:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:19:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:19:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:19:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:19:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:19:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:19:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:19:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:19:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:19:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:19:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:19:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:19:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:19:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:19:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:19:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:19:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:19:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:19:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:19:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:19:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:19:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:19:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:19:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:19:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:19:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:19:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:19:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:19:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:19:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:19:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:21:49 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-24 14:27:09 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-09-24 14:35:12 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-24 14:40:52 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-09-24 14:45:04 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-24 14:53:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:53:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:53:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:53:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:53:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:53:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:53:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:53:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:53:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:53:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:53:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:53:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:53:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:53:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:53:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:53:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:53:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:53:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:53:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:53:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:53:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:53:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:53:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:53:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:53:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:53:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:53:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:53:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:53:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:53:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:53:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:53:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:53:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:53:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:53:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:53:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:53:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:53:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:53:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:53:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:53:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:53:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:53:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:53:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:53:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:53:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:53:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:53:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:53:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:53:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:53:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:53:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:53:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:53:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:53:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:53:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:53:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:53:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:53:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:53:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:53:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:53:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:53:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:53:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:53:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:53:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:53:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:53:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:53:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:53:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:53:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:53:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 14:53:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:39 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:00:41 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:47 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:02:49 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:09:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:09:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:09:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:09:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:09:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:09:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:09:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:09:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:09:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:09:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:09:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:09:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:09:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:09:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:09:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:09:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:09:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:09:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:09:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:09:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:09:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:09:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:09:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:09:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:09:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:09:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:09:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:09:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:09:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:09:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:09:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:09:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:09:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:09:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:09:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:09:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:09:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:09:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:09:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:09:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:09:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:09:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:09:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:09:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:09:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:09:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:09:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:09:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:09:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:09:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:09:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:09:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:09:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:09:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:09:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:09:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:09:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:09:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:09:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:09:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:09:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:09:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:09:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:09:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:09:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:09:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:09:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:09:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:09:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:09:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:09:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:09:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:09:40 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-24 15:29:05 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-09-24 17:28:20 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
