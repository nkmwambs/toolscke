<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-09-25 05:44:36 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-09-25 05:44:39 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-09-25 05:44:39 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-09-25 05:55:29 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-09-25 05:55:29 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-09-25 06:21:56 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-09-25 06:29:20 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-25 06:29:40 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-25 06:31:43 --> 404 Page Not Found: Civa/assets
ERROR - 2019-09-25 06:36:31 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-09-25 06:40:06 --> 404 Page Not Found: Civa/assets
ERROR - 2019-09-25 06:40:22 --> 404 Page Not Found: Civa/assets
ERROR - 2019-09-25 06:46:57 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:19 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 06:55:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 07:18:11 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-25 07:20:27 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-25 07:20:27 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-25 07:30:13 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-09-25 07:37:28 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-25 07:50:39 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-25 07:53:15 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 81
ERROR - 2019-09-25 07:53:15 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 82
ERROR - 2019-09-25 07:56:50 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-25 07:56:51 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-25 07:57:13 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-25 07:57:48 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-25 09:10:51 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-25 09:22:19 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2019-09-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2019-09-25 09:30:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 09:30:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 09:30:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 09:30:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 09:30:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 09:30:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 09:30:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 09:30:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 09:30:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 09:30:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 09:30:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 09:30:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 09:30:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 09:30:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 09:30:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 09:30:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 09:30:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 09:30:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 09:30:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 09:30:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 09:30:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 09:30:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 09:30:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 09:30:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 09:30:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 09:30:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 09:30:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 09:30:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 09:30:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 09:30:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 09:30:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 09:30:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 09:30:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 09:30:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 09:30:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 09:30:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 09:30:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 09:30:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 09:30:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 09:30:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 09:30:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 09:30:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 09:30:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 09:30:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 09:30:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 09:30:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 09:30:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 09:30:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 09:30:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 09:30:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 09:30:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 09:30:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 09:30:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 09:30:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 09:30:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 09:30:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 09:30:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 09:30:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 09:30:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 09:30:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 09:30:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 09:30:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 09:30:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 09:30:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 09:30:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 09:30:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 09:30:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 09:30:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 09:30:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 09:30:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 09:30:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 09:30:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 09:30:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 09:30:09 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:05:58 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-25 10:12:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:44 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:12:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:16:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:16:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:16:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:16:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:16:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:16:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:16:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:16:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:16:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:16:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:16:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:16:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:16:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:16:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:16:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:16:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:16:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:16:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:16:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:16:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:16:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:16:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:16:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:16:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:16:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:16:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:16:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:16:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:16:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:16:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:16:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:16:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:16:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:16:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:16:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:16:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:16:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:16:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:16:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:16:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:16:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:16:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:16:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:16:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:16:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:16:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:16:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:16:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:16:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:16:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:16:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:16:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:16:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:16:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:16:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:16:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:16:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:16:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:16:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:16:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:16:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:16:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:16:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:16:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:16:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:16:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:16:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:16:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:16:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:16:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:16:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:16:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:16:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:16:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 10:22:01 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 81
ERROR - 2019-09-25 10:22:01 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 82
ERROR - 2019-09-25 10:43:40 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-25 11:16:04 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-25 11:35:23 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/health/dashboard.php 12
ERROR - 2019-09-25 11:35:30 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/health/dashboard.php 252
ERROR - 2019-09-25 11:35:32 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/health/dashboard.php 252
ERROR - 2019-09-25 11:35:35 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/health/dashboard.php 252
ERROR - 2019-09-25 11:35:35 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/health/dashboard.php 252
ERROR - 2019-09-25 11:35:44 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/health/dashboard.php 252
ERROR - 2019-09-25 11:35:52 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/health/dashboard.php 252
ERROR - 2019-09-25 11:35:52 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/health/dashboard.php 252
ERROR - 2019-09-25 11:36:11 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/health/dashboard.php 252
ERROR - 2019-09-25 11:41:12 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 81
ERROR - 2019-09-25 11:41:12 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 82
ERROR - 2019-09-25 11:42:33 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-25 11:47:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:47:59 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:27 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:57 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:57 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:57 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:57 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:57 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:57 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:57 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:57 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:57 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:57 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:57 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:57 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:57 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:57 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:57 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:57 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:57 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:57 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:57 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:57 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:57 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:57 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:57 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:57 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:57 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:57 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:57 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:57 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:57 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:57 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:57 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:57 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:57 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:57 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:57 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:57 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:57 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:57 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:57 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:57 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:57 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:57 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:57 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:57 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:57 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:57 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:57 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:57 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:57 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:57 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:57 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:57 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:57 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:57 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:57 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:57 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:57 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:57 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:57 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:57 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:57 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:57 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:57 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:57 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:57 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:57 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:57 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:57 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:57 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:57 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:57 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:57 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:57 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:48:57 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:07 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 11:51:54 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2019-09-25 12:00:18 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-25 12:03:09 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-09-25 12:03:33 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-25 12:03:33 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-25 12:32:22 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-25 12:33:51 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-09-25 12:45:56 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-09-25 12:54:58 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-25 13:35:21 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-25 14:24:47 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-25 14:32:56 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-25 14:39:57 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-25 14:49:18 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-25 14:50:17 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-25 14:55:23 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-09-25 16:15:54 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 81
ERROR - 2019-09-25 16:15:54 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 82
ERROR - 2019-09-25 16:16:38 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 81
ERROR - 2019-09-25 16:16:38 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 82
