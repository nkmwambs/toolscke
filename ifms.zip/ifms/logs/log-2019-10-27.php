<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-10-27 04:01:01 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-10-27 15:35:02 --> 404 Page Not Found: Civa/assets
ERROR - 2019-10-27 15:35:28 --> 404 Page Not Found: Civa/assets
ERROR - 2019-10-27 15:35:56 --> 404 Page Not Found: Civa/assets
ERROR - 2019-10-27 15:38:30 --> 404 Page Not Found: Civa/assets
ERROR - 2019-10-27 15:38:51 --> 404 Page Not Found: Civa/assets
ERROR - 2019-10-27 15:38:54 --> 404 Page Not Found: Civa/assets
ERROR - 2019-10-27 15:39:17 --> 404 Page Not Found: Civa/assets
ERROR - 2019-10-27 15:41:08 --> 404 Page Not Found: Civa/assets
ERROR - 2019-10-27 15:41:47 --> 404 Page Not Found: Civa/assets
ERROR - 2019-10-27 21:00:02 --> Severity: Warning --> rmdir(accountant+dashboard): No such file or directory /home/compatl8/public_html/tools/ifms/controllers/Crons.php 39
