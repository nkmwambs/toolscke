<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-11-10 10:40:00 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-11-10 14:56:41 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-11-10 17:30:25 --> 404 Page Not Found: Civa/assets
ERROR - 2019-11-10 17:55:32 --> 404 Page Not Found: Civa/assets
ERROR - 2019-11-10 21:00:02 --> Severity: Warning --> rmdir(accountant+dashboard): No such file or directory /home/compatl8/public_html/tools/ifms/controllers/Crons.php 39
