<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-11-14 05:54:39 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-11-14 06:33:25 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-11-14 07:53:05 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-11-14 08:47:26 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-11-14 08:48:02 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-11-14 09:07:49 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-11-14 09:26:56 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-11-14 09:41:47 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-11-14 09:41:48 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-11-14 09:41:51 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-11-14 09:41:53 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-11-14 09:44:56 --> 404 Page Not Found: Facilitator/assets
ERROR - 2019-11-14 09:45:36 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 81
ERROR - 2019-11-14 09:45:36 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 82
ERROR - 2019-11-14 09:52:10 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-11-14 09:52:21 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-11-14 10:28:31 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-11-14 10:28:31 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-11-14 10:28:33 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-11-14 11:05:44 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2019-11-14 11:09:10 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-11-14 11:10:04 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-11-14 11:10:12 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-11-14 11:10:23 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-11-14 11:10:32 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-11-14 11:10:40 --> 404 Page Not Found: Partner/0.9541709817797218
ERROR - 2019-11-14 11:10:44 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-11-14 11:18:09 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-11-14 11:26:19 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 81
ERROR - 2019-11-14 11:26:19 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 82
ERROR - 2019-11-14 11:31:27 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-11-14 11:31:32 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-11-14 11:31:34 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-11-14 11:31:35 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-11-14 11:31:37 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-11-14 11:31:38 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-11-14 11:33:32 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-11-14 12:14:46 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-11-14 12:15:10 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-11-14 12:15:47 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-11-14 12:18:30 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-11-14 12:18:52 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-11-14 12:19:11 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-11-14 12:19:25 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2019-11-14 14:03:00 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/health/dashboard.php 12
ERROR - 2019-11-14 14:03:09 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/health/dashboard.php 252
ERROR - 2019-11-14 14:03:11 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/health/dashboard.php 252
ERROR - 2019-11-14 14:03:15 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/health/dashboard.php 252
ERROR - 2019-11-14 14:03:24 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/health/dashboard.php 252
ERROR - 2019-11-14 14:03:33 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/health/dashboard.php 252
ERROR - 2019-11-14 14:03:33 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/health/dashboard.php 252
ERROR - 2019-11-14 14:03:55 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/health/dashboard.php 252
ERROR - 2019-11-14 14:05:02 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-11-14 14:08:19 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/health/dashboard.php 12
ERROR - 2019-11-14 14:08:28 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/health/dashboard.php 252
ERROR - 2019-11-14 14:08:30 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/health/dashboard.php 252
ERROR - 2019-11-14 14:08:34 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/health/dashboard.php 252
ERROR - 2019-11-14 14:08:43 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/health/dashboard.php 252
ERROR - 2019-11-14 14:08:52 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/health/dashboard.php 252
ERROR - 2019-11-14 14:08:52 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/health/dashboard.php 252
ERROR - 2019-11-14 14:09:13 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/health/dashboard.php 252
ERROR - 2019-11-14 14:16:02 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2019-11-14 21:00:02 --> Severity: Warning --> rmdir(accountant+dashboard): No such file or directory /home/compatl8/public_html/tools/ifms/controllers/Crons.php 39
