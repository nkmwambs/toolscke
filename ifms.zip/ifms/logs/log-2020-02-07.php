<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-02-07 03:02:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 03:02:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 03:02:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 03:02:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 03:02:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 03:02:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 03:02:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 03:02:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 03:02:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 03:02:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 03:02:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 03:02:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 03:02:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 03:02:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 03:02:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 03:02:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 03:02:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 03:02:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 03:02:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 03:02:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 03:02:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 03:02:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 03:02:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 03:02:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 03:02:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 03:02:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 03:02:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 03:02:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 03:02:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 03:02:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 03:02:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 03:02:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 03:02:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 03:02:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 03:02:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 03:02:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 03:02:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 03:02:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 03:02:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 03:02:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 03:02:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 03:02:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 03:02:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 03:02:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 03:02:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 03:02:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 03:02:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 03:02:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 03:02:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 03:02:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 03:02:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 03:02:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 03:02:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 03:02:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 03:02:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 03:02:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 03:02:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 03:02:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 03:02:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 03:02:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 03:02:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 03:02:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 03:02:21 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 03:45:36 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2020-02-07 04:13:57 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2020-02-07 06:17:25 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-07 06:25:36 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-07 06:46:30 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-07 06:46:31 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-07 06:46:31 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-07 06:46:31 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-07 06:46:36 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-07 06:46:36 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-07 06:47:17 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-07 06:47:19 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2020-02-07 07:03:45 --> 404 Page Not Found: Civa/assets
ERROR - 2020-02-07 07:06:03 --> 404 Page Not Found: Civa/assets
ERROR - 2020-02-07 07:12:22 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-07 07:12:22 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-07 07:12:24 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-07 07:12:26 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-07 07:42:29 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-07 07:42:31 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-07 08:01:41 --> 404 Page Not Found: Facilitator/assets
ERROR - 2020-02-07 08:13:30 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2020-02-07 08:13:46 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2020-02-07 08:32:44 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2020-02-07 08:33:21 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2020-02-07 08:39:40 --> 404 Page Not Found: Facilitator/assets
ERROR - 2020-02-07 09:24:33 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-07 09:29:39 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-07 09:57:36 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-07 10:19:18 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-07 10:19:20 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-07 10:20:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:20:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:20:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:20:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:20:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:20:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:20:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:20:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:20:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:20:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:20:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:20:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:20:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:20:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:20:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:20:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:20:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:20:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:20:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:20:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:20:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:20:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:20:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:20:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:20:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:20:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:20:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:20:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:20:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:20:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:20:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:20:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:20:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:20:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:20:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:20:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:20:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:20:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:20:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:20:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:20:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:20:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:20:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:20:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:20:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:20:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:20:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:20:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:20:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:20:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:20:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:20:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:20:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:20:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:20:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:20:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:20:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:20:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:20:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:20:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:20:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:20:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:20:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:20:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:20:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:23 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:37 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-07 10:23:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:23:45 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-07 10:42:02 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-07 10:50:56 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2020-02-07 12:01:50 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2020-02-07 12:02:31 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2020-02-07 12:06:56 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2020-02-07 12:07:30 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2020-02-07 12:07:30 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2020-02-07 12:07:31 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2020-02-07 12:28:59 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2020-02-07 12:46:12 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2020-02-07 12:47:49 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2020-02-07 13:53:49 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-07 13:53:49 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-07 13:53:52 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-07 13:53:53 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-07 13:53:54 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-07 14:03:31 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-07 21:00:02 --> Severity: Warning --> rmdir(accountant+dashboard): No such file or directory /home/compatl8/public_html/tools/ifms/controllers/Crons.php 39
