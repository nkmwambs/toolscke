<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-02-09 08:13:50 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 81
ERROR - 2020-02-09 08:13:50 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 82
ERROR - 2020-02-09 10:20:24 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-09 10:20:24 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-09 14:23:17 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-09 21:00:02 --> Severity: Warning --> rmdir(accountant+dashboard): No such file or directory /home/compatl8/public_html/tools/ifms/controllers/Crons.php 39
