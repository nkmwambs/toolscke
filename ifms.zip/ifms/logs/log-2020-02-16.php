<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-02-16 09:24:54 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-16 09:24:54 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-16 13:36:24 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-16 14:42:04 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-16 21:00:02 --> Severity: Warning --> rmdir(accountant+dashboard): No such file or directory /home/compatl8/public_html/tools/ifms/controllers/Crons.php 39
