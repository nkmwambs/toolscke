<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-02-22 00:39:08 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-22 05:56:48 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-22 06:07:00 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-22 06:35:26 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2020-02-22 07:17:33 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-22 07:19:04 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-22 07:27:16 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-22 07:44:55 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-22 07:46:03 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-22 07:49:11 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-22 07:50:54 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-22 08:19:33 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-22 08:20:23 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-22 08:20:24 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-22 08:24:49 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-22 08:24:50 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-22 08:30:41 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-22 08:35:11 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-22 08:35:11 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-22 08:35:12 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-22 08:35:14 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-22 08:35:15 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-22 09:01:09 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-22 09:49:39 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-22 09:49:40 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-22 09:49:41 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-22 09:49:42 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-22 09:49:43 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-22 11:27:10 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2020-02-22 11:27:11 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2020-02-22 14:46:19 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-22 14:48:48 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-22 15:02:48 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-22 15:10:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:10:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:10:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:10:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:10:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:10:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:10:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:10:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:10:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:10:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:10:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:10:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:10:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:10:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:10:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:10:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:10:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:10:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:10:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:10:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:10:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:10:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:10:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:10:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:10:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:10:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:10:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:10:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:10:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:10:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:10:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:10:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:10:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:10:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:10:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:10:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:10:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:10:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:10:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:10:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:10:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:10:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:10:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:10:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:10:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:10:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:10:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:10:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:10:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:10:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:10:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:10:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:10:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:10:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:10:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:10:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:10:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:10:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:10:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:10:42 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:11:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:11:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:11:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:11:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:11:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:11:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:11:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:11:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:11:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:11:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:11:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:11:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:11:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:11:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:11:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:11:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:11:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:11:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:11:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:11:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:11:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:11:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:11:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:11:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:11:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:11:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:11:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:11:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:11:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:11:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:11:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:11:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:11:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:11:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:11:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:11:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:11:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:11:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:11:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:11:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:11:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:11:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:11:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:11:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:11:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:11:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:11:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:11:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:11:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:11:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:11:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:11:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:11:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:11:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:11:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:11:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:11:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:11:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:11:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:11:19 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-22 15:40:51 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-22 19:10:04 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-22 19:16:47 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-22 21:00:01 --> Severity: Warning --> rmdir(accountant+dashboard): No such file or directory /home/compatl8/public_html/tools/ifms/controllers/Crons.php 39
