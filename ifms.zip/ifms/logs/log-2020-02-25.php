<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-02-25 03:34:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:14 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:15 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 03:34:16 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 06:36:48 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-25 06:38:29 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-25 06:39:05 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-25 06:40:00 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-25 06:54:34 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-25 07:06:48 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-25 07:06:51 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-25 07:54:39 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-25 07:57:31 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2020-02-25 08:19:31 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-25 08:28:20 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-25 08:30:32 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-25 08:38:31 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-25 08:38:31 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-25 08:46:12 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-25 09:14:30 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-25 09:15:40 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-25 09:25:30 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:30 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:30 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:30 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:30 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:30 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:30 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:30 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:30 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:30 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:30 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:30 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:30 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:30 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:30 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:30 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:30 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:30 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:30 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:30 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:30 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:30 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:30 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:30 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:30 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:30 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:25:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:51 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:27:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:00 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:01 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:33:34 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> date() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Accountant.php 117
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:56 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-25 09:38:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-25 09:52:13 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-25 09:55:50 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-25 10:07:24 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2020-02-25 10:10:32 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-25 10:13:05 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2020-02-25 10:15:21 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-25 10:29:09 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2020-02-25 10:30:00 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2020-02-25 10:30:09 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-25 10:33:51 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2020-02-25 10:34:49 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-25 10:35:46 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2020-02-25 10:36:54 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2020-02-25 10:36:59 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-25 10:36:59 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-25 10:37:00 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-25 10:37:12 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2020-02-25 10:39:56 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2020-02-25 10:40:18 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2020-02-25 10:42:10 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2020-02-25 10:43:27 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2020-02-25 10:45:08 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2020-02-25 10:45:41 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2020-02-25 10:46:47 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2020-02-25 10:48:56 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2020-02-25 10:50:27 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2020-02-25 10:51:59 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2020-02-25 10:52:36 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2020-02-25 10:53:10 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2020-02-25 10:54:14 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-25 10:54:19 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2020-02-25 10:54:38 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2020-02-25 10:55:11 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2020-02-25 10:55:51 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2020-02-25 10:56:29 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2020-02-25 10:56:33 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-25 10:57:14 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2020-02-25 10:57:32 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2020-02-25 10:58:01 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-25 10:58:04 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2020-02-25 10:58:36 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2020-02-25 10:59:23 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2020-02-25 10:59:55 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-25 11:00:22 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2020-02-25 11:00:57 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2020-02-25 11:01:22 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-25 11:03:46 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2020-02-25 11:05:02 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2020-02-25 11:05:51 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2020-02-25 11:06:15 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2020-02-25 11:07:06 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2020-02-25 11:09:48 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2020-02-25 11:09:53 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-25 11:13:01 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2020-02-25 11:13:33 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2020-02-25 11:13:36 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-25 11:14:11 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2020-02-25 11:14:39 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2020-02-25 11:16:03 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-25 11:16:55 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-25 11:17:30 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2020-02-25 11:18:18 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2020-02-25 11:19:12 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2020-02-25 11:19:32 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2020-02-25 11:19:55 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2020-02-25 11:21:52 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2020-02-25 11:24:22 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2020-02-25 11:26:05 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2020-02-25 11:26:39 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2020-02-25 11:27:23 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-25 11:29:02 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2020-02-25 11:31:46 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2020-02-25 11:34:28 --> Severity: Warning --> A non-numeric value encountered /home/compatl8/public_html/tools/ifms/views/backend/partner/budget_schedules.php 41
ERROR - 2020-02-25 11:46:25 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 81
ERROR - 2020-02-25 11:46:25 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 82
ERROR - 2020-02-25 12:10:28 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2020-02-25 12:18:50 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-25 12:21:59 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-25 12:44:21 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2020-02-25 13:10:56 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 81
ERROR - 2020-02-25 13:10:56 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 82
ERROR - 2020-02-25 13:16:46 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-25 13:19:26 --> 404 Page Not Found: Civa/assets
ERROR - 2020-02-25 13:19:35 --> 404 Page Not Found: Civa/assets
ERROR - 2020-02-25 13:26:48 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-25 13:29:24 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-25 13:29:47 --> 404 Page Not Found: Facilitator/assets
ERROR - 2020-02-25 13:31:11 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-25 13:32:27 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-25 13:36:51 --> 404 Page Not Found: Facilitator/assets
ERROR - 2020-02-25 13:37:48 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-25 13:40:21 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-25 13:44:59 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-25 14:07:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:07:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:07:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:07:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:07:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:07:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:07:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:07:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:07:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:07:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:07:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:07:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:07:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:07:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:07:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:07:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:07:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:07:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:07:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:07:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:07:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:07:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:07:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:07:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:07:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:07:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:07:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:07:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:07:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:07:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:07:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:07:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:07:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:07:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:07:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:07:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:07:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:07:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:07:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:07:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:07:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:07:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:07:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:07:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:07:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:07:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:07:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:07:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:07:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:07:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:07:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:07:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:07:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:07:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:07:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:07:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:07:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:07:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:07:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:07:32 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:09:03 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2020-02-25 14:10:19 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2020-02-25 14:18:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:18:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:18:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:18:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:18:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:18:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:18:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:18:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:18:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:18:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:18:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:18:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:18:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:18:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:18:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:18:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:18:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:18:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:18:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:18:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:18:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:18:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:18:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:18:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:18:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:18:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:18:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:18:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:18:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:18:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:18:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:18:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:18:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:18:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:18:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:18:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:18:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:18:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:18:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:18:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:18:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:18:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:18:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:18:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:18:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:18:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:18:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:18:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:18:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:18:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:18:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:18:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:18:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:18:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:18:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:18:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:18:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:18:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:18:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:18:22 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:21:50 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-25 14:27:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:27:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:27:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:27:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:27:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:27:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:27:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:27:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:27:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:27:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:27:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:27:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:27:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:27:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:27:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:27:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:27:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:27:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:27:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:27:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:27:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:27:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:27:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:27:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:27:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:27:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:27:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:27:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:27:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:27:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:27:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:27:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:27:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:27:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:27:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:27:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:27:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:27:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:27:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:27:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:27:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:27:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:27:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:27:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:27:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:27:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:27:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:27:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:27:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:27:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:27:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:27:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:27:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:27:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:27:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:27:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:27:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:27:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:27:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:27:01 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:28:55 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:28:55 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:28:55 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:28:55 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:28:55 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:28:55 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:28:55 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:28:55 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:28:55 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:28:55 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:28:55 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:28:55 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:28:55 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:28:55 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:28:55 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:28:55 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:28:55 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:28:55 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:28:55 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:28:55 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:28:55 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:28:55 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:28:55 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:28:55 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:28:55 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:28:55 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:28:55 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:28:55 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:28:55 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:28:55 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:28:55 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:28:55 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:28:55 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:28:55 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:28:55 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:28:55 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:28:55 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:28:55 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:28:55 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:28:55 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:28:55 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:28:55 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:28:55 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:28:55 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:28:55 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:28:55 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:28:55 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:28:55 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:28:55 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:28:55 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:28:55 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:28:55 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:28:55 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:28:55 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:28:55 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:28:55 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:28:55 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:28:55 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:28:55 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:28:55 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:31:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:31:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:31:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:31:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:31:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:31:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:31:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:31:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:31:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:31:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:31:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:31:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:31:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:31:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:31:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:31:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:31:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:31:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:31:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:31:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:31:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:31:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:31:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:31:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:31:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:31:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:31:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:31:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:31:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:31:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:31:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:31:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:31:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:31:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:31:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:31:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:31:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:31:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:31:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:31:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:31:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:31:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:31:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:31:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:31:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:31:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:31:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:31:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:31:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:31:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:31:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:31:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:31:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:31:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:31:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:31:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:31:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:31:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:31:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:31:28 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:32:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:32:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:32:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:32:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:32:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:32:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:32:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:32:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:32:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:32:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:32:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:32:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:32:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:32:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:32:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:32:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:32:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:32:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:32:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:32:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:32:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:32:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:32:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:32:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:32:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:32:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:32:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:32:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:32:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:32:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:32:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:32:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:32:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:32:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:32:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:32:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:32:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:32:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:32:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:32:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:32:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:32:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:32:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:32:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:32:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:32:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:32:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:32:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:32:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:32:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:32:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:32:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:32:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:32:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:32:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:32:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:32:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:32:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:32:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:32:43 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:34:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:34:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:34:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:34:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:34:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:34:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:34:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:34:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:34:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:34:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:34:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:34:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:34:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:34:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:34:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:34:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:34:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:34:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:34:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:34:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:34:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:34:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:34:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:34:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:34:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:34:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:34:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:34:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:34:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:34:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:34:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:34:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:34:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:34:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:34:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:34:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:34:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:34:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:34:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:34:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:34:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:34:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:34:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:34:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:34:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:34:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:34:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:34:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:34:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:34:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:34:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:34:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:34:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:34:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:34:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:34:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:34:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:34:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:34:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:34:08 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:36:12 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:36:13 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:36:13 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:36:13 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:36:13 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:36:13 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:36:13 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:36:13 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:36:13 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:36:13 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:36:13 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:36:13 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:36:13 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:36:13 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:36:13 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:36:13 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:36:13 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:36:13 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:36:13 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:36:13 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:36:13 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:36:13 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:36:13 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:36:13 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:36:13 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:36:13 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:36:13 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:36:13 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:36:13 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:36:13 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:36:13 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:36:13 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:36:13 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:36:13 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:36:13 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:36:13 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:36:13 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:36:13 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:36:13 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:36:13 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:36:13 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:36:13 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:36:13 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:36:13 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:36:13 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:36:13 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:36:13 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:36:13 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:36:13 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:36:13 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:36:13 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:36:13 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:36:13 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:36:13 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:36:13 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:36:13 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:36:13 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:36:13 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:36:13 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:36:13 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:36:31 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-25 14:36:40 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-25 14:47:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:47:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:47:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:47:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:47:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:47:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:47:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:47:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:47:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:47:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:47:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:47:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:47:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:47:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:47:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:47:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:47:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:47:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:47:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:47:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:47:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:47:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:47:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:47:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:47:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:47:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:47:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:47:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:47:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:47:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:47:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:47:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:47:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:47:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:47:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:47:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:47:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:47:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:47:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:47:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:47:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:47:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:47:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:47:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:47:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:47:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:47:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:47:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:47:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:47:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:47:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:47:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:47:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:47:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:47:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:47:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:47:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:47:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:47:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 14:47:05 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-25 16:18:07 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 81
ERROR - 2020-02-25 16:18:07 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 82
ERROR - 2020-02-25 16:31:09 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 81
ERROR - 2020-02-25 16:31:09 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 82
ERROR - 2020-02-25 16:38:41 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 81
ERROR - 2020-02-25 16:38:41 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 82
ERROR - 2020-02-25 16:43:32 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 81
ERROR - 2020-02-25 16:43:32 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 82
ERROR - 2020-02-25 16:53:34 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 81
ERROR - 2020-02-25 16:53:34 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 82
ERROR - 2020-02-25 17:09:54 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 81
ERROR - 2020-02-25 17:09:54 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 82
ERROR - 2020-02-25 17:18:50 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 81
ERROR - 2020-02-25 17:18:50 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 82
ERROR - 2020-02-25 18:16:01 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-25 18:33:53 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-25 19:36:31 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-25 19:37:05 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
