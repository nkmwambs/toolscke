<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-02-27 05:58:59 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-27 06:06:04 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 81
ERROR - 2020-02-27 06:06:04 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 82
ERROR - 2020-02-27 06:15:47 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-27 06:32:34 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-27 06:35:27 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-27 06:40:28 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-27 06:46:50 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-27 06:49:04 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-27 06:49:10 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-27 06:49:10 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-27 06:49:23 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-27 06:49:24 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-27 06:49:25 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-27 06:49:53 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-27 06:50:00 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-27 06:50:01 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-27 06:50:02 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-27 06:53:03 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/partner/expense_report_data.php 66
ERROR - 2020-02-27 07:07:44 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-27 07:07:56 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 81
ERROR - 2020-02-27 07:07:56 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 82
ERROR - 2020-02-27 07:08:31 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-27 07:09:05 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-27 07:09:06 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-27 07:09:06 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-27 07:09:06 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-27 07:09:06 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-27 07:09:07 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-27 07:09:08 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-27 07:18:41 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-27 07:18:49 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-27 07:19:07 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-27 07:19:17 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-27 07:19:32 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-27 07:19:51 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-27 07:20:03 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-27 07:20:10 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-27 07:20:16 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-27 07:20:26 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-27 07:21:40 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-27 07:21:47 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-27 07:21:54 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-27 07:22:45 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-27 07:25:03 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-27 07:26:14 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-27 07:26:15 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-27 07:28:01 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 81
ERROR - 2020-02-27 07:28:01 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 82
ERROR - 2020-02-27 07:32:52 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2020-02-27 07:34:22 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2020-02-27 07:36:33 --> 404 Page Not Found: Facilitator/assets
ERROR - 2020-02-27 07:37:27 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2020-02-27 07:37:46 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2020-02-27 07:39:07 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2020-02-27 07:39:07 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2020-02-27 07:44:12 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2020-02-27 07:44:25 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-27 07:45:34 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2020-02-27 07:46:06 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2020-02-27 07:46:08 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-27 07:46:37 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2020-02-27 07:47:08 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2020-02-27 07:47:40 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2020-02-27 07:48:14 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2020-02-27 07:54:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:32 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> array_column() expects parameter 1 to be array, null given /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2235
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2237
ERROR - 2020-02-27 07:54:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/compatl8/public_html/tools/ifms/models/Finance_model.php 2218
ERROR - 2020-02-27 07:57:13 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-27 08:14:37 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 81
ERROR - 2020-02-27 08:14:37 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 82
ERROR - 2020-02-27 08:14:52 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 81
ERROR - 2020-02-27 08:14:52 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 82
ERROR - 2020-02-27 08:15:23 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-27 08:54:25 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-27 09:00:34 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-27 09:25:13 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-27 09:35:12 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-27 10:15:31 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-27 10:49:11 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:49:11 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:49:11 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:49:11 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:49:11 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:49:11 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:49:11 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:49:11 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:49:11 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:49:11 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:49:11 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:49:11 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:49:11 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:49:11 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:49:11 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:49:11 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:49:11 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:49:11 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:49:11 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:49:11 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:49:11 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:49:11 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:49:11 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:49:11 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:49:11 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:49:11 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:49:11 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:49:11 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:49:11 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:49:11 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:49:11 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:49:11 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:49:11 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:49:11 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:49:11 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:49:11 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:49:11 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:49:11 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:49:11 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:49:11 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:49:11 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:49:11 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:49:11 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:49:11 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:49:11 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:49:11 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:49:11 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:49:11 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:49:11 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:49:11 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:49:11 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:49:11 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:49:11 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:49:11 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:49:11 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:49:11 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:49:11 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:49:11 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:49:11 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:49:11 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:50 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:51 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:50:52 --> Severity: Warning --> substr_count(): Empty substring /home/compatl8/public_html/tools/ifms/controllers/Partner.php 761
ERROR - 2020-02-27 10:52:53 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-27 10:52:54 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-27 11:04:11 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2020-02-27 11:12:53 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-27 11:12:54 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-27 11:12:55 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-27 11:27:28 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-27 11:27:28 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-27 11:27:29 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-27 11:27:30 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-27 11:29:30 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-27 11:29:31 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-27 12:13:52 --> 404 Page Not Found: Facilitator/assets
ERROR - 2020-02-27 12:28:43 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-27 12:29:21 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-27 12:29:21 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-27 12:29:22 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-27 12:29:22 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-27 12:29:24 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-27 12:29:27 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-27 12:29:27 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-27 12:29:28 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-27 12:34:34 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/health/dashboard.php 12
ERROR - 2020-02-27 12:34:43 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/health/dashboard.php 252
ERROR - 2020-02-27 12:34:45 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/health/dashboard.php 252
ERROR - 2020-02-27 12:34:49 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/health/dashboard.php 252
ERROR - 2020-02-27 12:34:59 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/health/dashboard.php 252
ERROR - 2020-02-27 12:35:09 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/health/dashboard.php 252
ERROR - 2020-02-27 12:35:09 --> Severity: Warning --> Division by zero /home/compatl8/public_html/tools/ifms/views/backend/health/dashboard.php 252
ERROR - 2020-02-27 12:35:36 --> Severity: Error --> Allowed memory size of 402653184 bytes exhausted (tried to allocate 16384 bytes) /home/compatl8/public_html/tools/system/database/drivers/pdo/pdo_driver.php 184
ERROR - 2020-02-27 12:40:14 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-27 12:41:16 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-27 13:30:01 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-27 13:30:07 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-27 13:30:09 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-27 13:44:13 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-27 14:17:58 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2020-02-27 14:19:57 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-27 14:46:38 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 81
ERROR - 2020-02-27 14:46:38 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 82
ERROR - 2020-02-27 15:35:58 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 81
ERROR - 2020-02-27 15:35:58 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 82
ERROR - 2020-02-27 17:11:57 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 81
ERROR - 2020-02-27 17:11:57 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 82
ERROR - 2020-02-27 17:12:55 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 81
ERROR - 2020-02-27 17:12:55 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 82
ERROR - 2020-02-27 17:20:22 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 81
ERROR - 2020-02-27 17:20:22 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 82
ERROR - 2020-02-27 17:21:43 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 81
ERROR - 2020-02-27 17:21:43 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 82
ERROR - 2020-02-27 17:25:19 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 81
ERROR - 2020-02-27 17:25:19 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 82
ERROR - 2020-02-27 17:26:02 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-27 17:26:03 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-27 17:28:12 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 81
ERROR - 2020-02-27 17:28:12 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 82
ERROR - 2020-02-27 17:30:44 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 81
ERROR - 2020-02-27 17:30:44 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 82
ERROR - 2020-02-27 17:33:13 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 81
ERROR - 2020-02-27 17:33:13 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 82
ERROR - 2020-02-27 17:34:50 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 81
ERROR - 2020-02-27 17:34:50 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 82
ERROR - 2020-02-27 17:35:49 --> Severity: error --> Exception: Too few arguments to function Partner::chqIntel(), 0 passed in /home/compatl8/public_html/tools/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/compatl8/public_html/tools/ifms/controllers/Partner.php 772
ERROR - 2020-02-27 17:37:23 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 81
ERROR - 2020-02-27 17:37:23 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 82
ERROR - 2020-02-27 17:41:41 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 81
ERROR - 2020-02-27 17:41:41 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 82
ERROR - 2020-02-27 17:43:36 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 81
ERROR - 2020-02-27 17:43:36 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 82
ERROR - 2020-02-27 17:45:48 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 81
ERROR - 2020-02-27 17:45:48 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 82
ERROR - 2020-02-27 17:48:05 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 81
ERROR - 2020-02-27 17:48:05 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 82
ERROR - 2020-02-27 17:50:47 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 81
ERROR - 2020-02-27 17:50:47 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 82
ERROR - 2020-02-27 17:53:26 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 81
ERROR - 2020-02-27 17:53:26 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 82
ERROR - 2020-02-27 17:56:09 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 81
ERROR - 2020-02-27 17:56:09 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 82
ERROR - 2020-02-27 17:59:42 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 81
ERROR - 2020-02-27 17:59:42 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 82
ERROR - 2020-02-27 18:02:43 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 81
ERROR - 2020-02-27 18:02:43 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 82
ERROR - 2020-02-27 18:05:34 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 81
ERROR - 2020-02-27 18:05:34 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 82
ERROR - 2020-02-27 18:10:55 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 81
ERROR - 2020-02-27 18:10:55 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 82
ERROR - 2020-02-27 18:15:03 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 81
ERROR - 2020-02-27 18:15:03 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 82
ERROR - 2020-02-27 18:16:44 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 81
ERROR - 2020-02-27 18:16:44 --> Severity: Warning --> strtotime() expects parameter 2 to be integer, string given /home/compatl8/public_html/tools/ifms/controllers/Partner.php 82
