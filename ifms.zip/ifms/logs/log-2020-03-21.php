<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-21 07:36:56 --> 404 Page Not Found: Accountant/assets
ERROR - 2020-03-21 07:53:31 --> Severity: Warning --> session_write_close(): Failed to write session data using user defined save handler. (session.save_path: ci_sessions) Unknown 0
ERROR - 2020-03-21 21:00:01 --> Severity: Warning --> rmdir(accountant+dashboard): No such file or directory /home/compatl8/public_html/tools/ifms/controllers/Crons.php 39
