<div class="row">
		<div class="col-sm-12">
	
			<div class="panel panel-primary" data-collapsed="0">
        	<div class="panel-heading">
            	<div class="panel-title" >
            		<i class="entypo-plus-circled"></i>
					<?php echo get_phrase('financial_report');?>
            	</div>
            </div>
			<div class="panel-body">	
				
			</div>
		</div>
	</div>	
</div>